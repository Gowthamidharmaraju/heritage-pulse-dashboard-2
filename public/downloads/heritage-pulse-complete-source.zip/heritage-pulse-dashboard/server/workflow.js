const db = require('./db');

const STAGES = {
  TOPIC_CREATED: { code: 'TOPIC_CREATED', label: 'Topic Created', progress: 0, color: '#64748b' },
  ASSIGNED: { code: 'ASSIGNED', label: 'Writer Assigned', progress: 10, color: '#3b82f6' },
  WRITING: { code: 'WRITING', label: 'Writing In Progress', progress: 25, color: '#a855f7' },
  CONTENT_COMPLETED: { code: 'CONTENT_COMPLETED', label: 'Content Completed', progress: 40, color: '#8b5cf6' },
  IMAGES_PENDING: { code: 'IMAGES_PENDING', label: 'Images Pending', progress: 45, color: '#f97316' },
  IMAGES_UPLOADED: { code: 'IMAGES_UPLOADED', label: 'Images Uploaded', progress: 50, color: '#f97316' },
  WRITER_SUBMITTED: { code: 'WRITER_SUBMITTED', label: 'Submitted to Editor', progress: 60, color: '#eab308' },
  EDITOR_REVIEW: { code: 'EDITOR_REVIEW', label: 'Editor Review In Progress', progress: 70, color: '#6366f1' },
  CHANGES_REQUIRED: { code: 'CHANGES_REQUIRED', label: 'Changes Required', progress: 35, color: '#ef4444' },
  EDITOR_APPROVED: { code: 'EDITOR_APPROVED', label: 'Editor Approved', progress: 80, color: '#0d9488' },
  FINAL_REVIEW: { code: 'FINAL_REVIEW', label: 'Final Approval Stage', progress: 90, color: '#1e3a8a' },
  READY_TO_PUBLISH: { code: 'READY_TO_PUBLISH', label: 'Ready for Website Publishing', progress: 95, color: '#059669' },
  PUBLISHED: { code: 'PUBLISHED', label: 'Published (100% Complete)', progress: 100, color: '#16a34a' }
};

class WorkflowEngine {
  getStages() {
    return STAGES;
  }

  // Advance or change content workflow status
  transition(contentId, targetStatus, userId, options = {}) {
    const rawData = db.load();
    const content = rawData.content.find(c => c.id === contentId);
    if (!content) throw new Error(`Content item ${contentId} not found`);

    const user = rawData.users.find(u => u.id === userId) || rawData.users[0];
    const previousStatus = content.status;
    const stageInfo = STAGES[targetStatus];
    if (!stageInfo) throw new Error(`Invalid target status: ${targetStatus}`);

    const now = new Date().toISOString();

    // Specific business rules for transitions
    if (targetStatus === 'PUBLISHED') {
      if (!options.published_url) {
        options.published_url = `https://heritagepulse.org/${(content.category || 'culture').toLowerCase()}/${content.id.toLowerCase()}-${encodeURIComponent(content.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 40))}`;
      }
      content.published_url = options.published_url;
      content.publishing_date = options.publishing_date || "2026-08-24";
      if (!content.checklist) content.checklist = {};
      content.checklist.website_published = true;
    }

    if (targetStatus === 'CHANGES_REQUIRED') {
      // Progress moves backward
      content.progress = 35;
    } else {
      content.progress = stageInfo.progress;
    }

    content.status = targetStatus;
    content.updated_at = now;

    // Record in workflow history
    const historyEntry = {
      id: `wf-${Date.now()}`,
      content_id: contentId,
      user_id: user.id,
      user_name: user.name,
      user_role: user.role,
      action: targetStatus,
      previous_status: previousStatus,
      new_status: targetStatus,
      progress: content.progress,
      comment: options.comment || `Moved to ${stageInfo.label} by ${user.name} (${user.role}).`,
      created_at: now
    };

    rawData.workflow_history.unshift(historyEntry);

    // Create notifications based on target stage
    if (targetStatus === 'WRITER_SUBMITTED') {
      if (content.editor_id) {
        rawData.notifications.unshift({
          id: `notif-${Date.now()}`,
          user_id: content.editor_id,
          content_id: contentId,
          title: "Article Submitted for Review",
          message: `${user.name} submitted '${content.title}' for editorial review.`,
          type: "SUBMISSION",
          read: false,
          created_at: now
        });
      }
    } else if (targetStatus === 'CHANGES_REQUIRED') {
      if (content.writer_id) {
        rawData.notifications.unshift({
          id: `notif-${Date.now()}`,
          user_id: content.writer_id,
          content_id: contentId,
          title: "Revisions Requested",
          message: `Editor ${user.name} requested changes on '${content.title}': ${options.comment || 'Please check editor notes.'}`,
          type: "CHANGES_REQUIRED",
          read: false,
          created_at: now
        });
      }
    } else if (targetStatus === 'FINAL_REVIEW' || targetStatus === 'EDITOR_APPROVED') {
      if (content.final_approver_id || content.editor_id) {
        rawData.notifications.unshift({
          id: `notif-${Date.now()}`,
          user_id: content.final_approver_id || content.editor_id,
          content_id: contentId,
          title: "Article Ready for Final Review",
          message: `'${content.title}' was approved by ${user.name} and is waiting for Final Approval.`,
          type: "APPROVAL",
          read: false,
          created_at: now
        });
      }
    } else if (targetStatus === 'PUBLISHED') {
      rawData.notifications.unshift({
        id: `notif-${Date.now()}`,
        user_id: "all",
        content_id: contentId,
        title: "Article Published 100%!",
        message: `'${content.title}' is now live on Heritage Pulse by Gowthami at ${content.published_url}`,
        type: "PUBLISHED",
        read: false,
        created_at: now
      });
    }

    // Also create version snapshot recording stage, author, and timestamp
    const existingVersions = rawData.versions.filter(v => v.content_id === contentId);
    const nextVer = existingVersions.length + 1;
    const wordCount = (content.body || '').replace(/<[^>]*>/g, ' ').split(/\s+/).filter(Boolean).length;
    
    rawData.versions.unshift({
      id: `ver-${contentId}-${nextVer}`,
      content_id: contentId,
      version_number: nextVer,
      version_label: `Version ${nextVer} — ${stageInfo.label}`,
      author_name: `${user.name} (${user.role})`,
      author_avatar: user.avatar || 'HP',
      stage: targetStatus,
      stage_label: stageInfo.label,
      progress: content.progress,
      word_count: wordCount,
      title: content.title,
      body: content.body,
      created_at: now
    });

    db.save(rawData);
    return db.getContentById(contentId);
  }
}

module.exports = new WorkflowEngine();
