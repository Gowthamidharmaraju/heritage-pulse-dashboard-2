const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const db = require('./db');
const workflow = require('./workflow');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Set up image upload storage
const uploadDir = path.join(__dirname, '..', 'public', 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
    cb(null, unique);
  }
});
const upload = multer({ storage, limits: { fileSize: 15 * 1024 * 1024 } });

// Serve static frontend
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/uploads', express.static(uploadDir));

// --- API ROUTES ---

// Health
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', app: 'Heritage Pulse Content Ops API', version: '1.0.0', time: new Date().toISOString() });
});

// Users
app.get('/api/users', (req, res) => {
  res.json(db.getUsers());
});

app.get('/api/users/:id', (req, res) => {
  const user = db.getUserById(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(user);
});

app.post('/api/users', (req, res) => {
  const raw = db.load();
  const newUser = {
    id: `usr-${Date.now()}`,
    name: req.body.name || 'New Team Member',
    email: req.body.email || `user${Date.now()}@heritagepulse.org`,
    role: req.body.role || 'Writer',
    title: req.body.title || 'Staff Contributor',
    avatar: (req.body.name || 'NT').split(' ').map(n => n[0]).join('').toUpperCase().slice(0,2),
    status: req.body.status || 'Active',
    phone: req.body.phone || '+91 90000 00000',
    assignedCategories: req.body.assignedCategories || ['All'],
    created_at: new Date().toISOString()
  };
  raw.users.push(newUser);
  db.save(raw);
  res.status(201).json(newUser);
});

app.put('/api/users/:id', (req, res) => {
  const raw = db.load();
  const idx = raw.users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'User not found' });
  raw.users[idx] = { ...raw.users[idx], ...req.body };
  db.save(raw);
  res.json(raw.users[idx]);
});

// Categories
app.get('/api/categories', (req, res) => {
  res.json(db.getCategories());
});

app.post('/api/categories', (req, res) => {
  const raw = db.load();
  const slug = (req.body.name || 'cat').toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const newCat = {
    id: `cat-${slug}-${Date.now()}`,
    name: req.body.name,
    slug: slug,
    description: req.body.description || '',
    color: req.body.color || '#d97706',
    icon: req.body.icon || 'bookmark',
    active: true
  };
  raw.categories.push(newCat);
  db.save(raw);
  res.status(201).json(newCat);
});

app.put('/api/categories/:id', (req, res) => {
  const raw = db.load();
  const idx = raw.categories.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Category not found' });
  raw.categories[idx] = { ...raw.categories[idx], ...req.body };
  db.save(raw);
  res.json(raw.categories[idx]);
});

app.delete('/api/categories/:id', (req, res) => {
  const raw = db.load();
  raw.categories = raw.categories.filter(c => c.id !== req.params.id);
  db.save(raw);
  res.json({ success: true });
});

// Content Management
app.get('/api/content', (req, res) => {
  const items = db.getContentList(req.query);
  res.json(items);
});

app.get('/api/content/:id', (req, res) => {
  const item = db.getContentById(req.params.id);
  if (!item) return res.status(404).json({ error: 'Content not found' });
  res.json(item);
});

app.post('/api/content', (req, res) => {
  const userId = req.headers['x-user-id'] || 'usr-admin-1';
  try {
    const newItem = db.createContent(req.body, userId);
    res.status(201).json(newItem);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/content/:id', (req, res) => {
  const userId = req.headers['x-user-id'] || 'usr-admin-1';
  const updated = db.updateContent(req.params.id, req.body, userId);
  if (!updated) return res.status(404).json({ error: 'Content not found' });
  res.json(updated);
});

app.delete('/api/content/:id', (req, res) => {
  const success = db.deleteContent(req.params.id);
  res.json({ success });
});

// Workflow Stage Transition
app.post('/api/content/:id/workflow', (req, res) => {
  const { status, comment, published_url, publishing_date } = req.body;
  const userId = req.headers['x-user-id'] || 'usr-admin-1';
  try {
    const updated = workflow.transition(req.params.id, status, userId, {
      comment,
      published_url,
      publishing_date
    });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Editorial Comments / Notes
app.post('/api/content/:id/comments', (req, res) => {
  const userId = req.headers['x-user-id'] || 'usr-editor-1';
  try {
    const comment = db.addComment(req.params.id, req.body, userId);
    res.status(201).json(comment);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Image Upload Endpoint
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  const fileUrl = `/uploads/${req.file.filename}`;
  res.json({
    url: fileUrl,
    filename: req.file.originalname,
    size: req.file.size,
    mimetype: req.file.mimetype
  });
});

// Content Images Management
app.post('/api/content/:id/images', (req, res) => {
  const raw = db.load();
  const item = raw.content.find(c => c.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Content not found' });

  if (!item.images) item.images = [];

  const newImg = {
    id: `img-${Date.now()}`,
    file_url: req.body.file_url,
    filename: req.body.filename || 'heritage-image.jpg',
    caption: req.body.caption || '',
    credit: req.body.credit || 'Heritage Pulse Bureau',
    alt_text: req.body.alt_text || '',
    is_featured: req.body.is_featured || item.images.length === 0,
    sort_order: item.images.length + 1
  };

  // If set to featured, unfeature others
  if (newImg.is_featured) {
    item.images.forEach(img => img.is_featured = false);
    item.featured_image = newImg.file_url;
  }

  item.images.push(newImg);

  // Automatically update workflow progress if at WRITING stage and uploaded images
  if (item.status === 'WRITING' && item.images.length >= 1) {
    item.status = 'IMAGES_UPLOADED';
    item.progress = 50;
  }

  item.updated_at = new Date().toISOString();
  db.save(raw);
  res.status(201).json(item);
});

app.delete('/api/content/:id/images/:imgId', (req, res) => {
  const raw = db.load();
  const item = raw.content.find(c => c.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Content not found' });

  item.images = (item.images || []).filter(img => img.id !== req.params.imgId);
  item.updated_at = new Date().toISOString();
  db.save(raw);
  res.json({ success: true, images: item.images });
});

// Publishing Action
app.post('/api/content/:id/publish', (req, res) => {
  const userId = req.headers['x-user-id'] || 'usr-publisher-1';
  const { published_url, publishing_date } = req.body;
  try {
    const updated = workflow.transition(req.params.id, 'PUBLISHED', userId, {
      published_url,
      publishing_date: publishing_date || "2026-08-24",
      comment: "Article marked as Published (100% complete) on live Heritage Pulse site."
    });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Notifications
app.get('/api/notifications', (req, res) => {
  const userId = req.query.user_id || req.headers['x-user-id'];
  res.json(db.getNotifications(userId));
});

app.post('/api/notifications/:id/read', (req, res) => {
  db.markNotificationRead(req.params.id);
  res.json({ success: true });
});

app.post('/api/notifications/read-all', (req, res) => {
  const userId = req.body.user_id || req.headers['x-user-id'];
  db.markAllNotificationsRead(userId);
  res.json({ success: true });
});

// Analytics & Reports
app.get('/api/analytics/overview', (req, res) => {
  res.json(db.getAnalytics());
});

// Reset Database to Original Seed Data
app.post('/api/admin/reset-seed', (req, res) => {
  try {
    if (fs.existsSync(path.join(__dirname, 'data.json'))) {
      fs.unlinkSync(path.join(__dirname, 'data.json'));
    }
    db.init();
    res.json({ success: true, message: 'Database reset to initial editorial seed data' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Fallback for SPA routing
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// Start Server
app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(` Heritage Pulse Editorial Operations Dashboard `);
  console.log(` Server running at: http://localhost:${PORT}`);
  console.log(` Date context: August 24, 2026`);
  console.log(`====================================================`);
});
