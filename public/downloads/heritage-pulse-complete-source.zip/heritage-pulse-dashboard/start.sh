#!/bin/bash
cd "$(dirname "$0")"

echo "=================================================="
echo "  Starting Heritage Pulse Dashboard Server...     "
echo "=================================================="

# Check if node_modules exists, otherwise install
if [ ! -d "node_modules" ]; then
  echo "Installing project dependencies..."
  npm install
fi

# Open browser in background
(sleep 1 && open "http://localhost:3000") &

# Start server
node server/index.js
