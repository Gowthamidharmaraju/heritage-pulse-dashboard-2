// Heritage Pulse Editorial Operations Core Application Controller with Real-Time Data Sync
class App {
  constructor() {
    this.currentView = 'dashboard';
    this.viewParams = {};
    this.currentUser = {
      id: "usr-admin-1",
      name: "Jitendra",
      role: "Admin",
      avatar: "J",
      title: "Admin & Head of Content Ops"
    };
    this.theme = localStorage.getItem('hp_theme') || 'dark';
    this.categories = [];
    this.users = [];
    this.notifications = [];
    this.realtimeTimer = null;
    this.lastSyncTimestamp = Date.now();
  }

  async init() {
    console.log("Initializing Heritage Pulse Editorial Operations Platform (Realtime Active)...");
    
    // Apply saved theme
    this.applyTheme(this.theme);

    // Bind global events
    this.bindEvents();

    // Fetch initial baseline metadata
    try {
      const [users, categories, notifs] = await Promise.all([
        this.apiGet('/api/users'),
        this.apiGet('/api/categories'),
        this.apiGet('/api/notifications')
      ]);
      this.users = users;
      this.categories = categories;
      this.notifications = notifs;

      // Update current user if exists in DB
      const dbUser = this.users.find(u => u.id === this.currentUser.id);
      if (dbUser) this.currentUser = dbUser;

      this.updateHeaderProfile();
      this.updateNotificationBadge();
      this.populateCreateModalSelects();

      // Handle URL hash route
      window.addEventListener('hashchange', () => this.handleRoute());
      this.handleRoute();

      // Start Live Real-Time Clock with Seconds
      this.startLiveClock();

      // Start Real-Time Background Synchronization (Every 3.5 seconds)
      this.startRealtimeSync();

    } catch (err) {
      console.error("Initialization error:", err);
      this.showToast("Server communication error. Check console.", "error");
    }
  }

  // Live Real-Time Digital Clock with Seconds Ticker
  startLiveClock() {
    if (this.clockTimer) clearInterval(this.clockTimer);
    
    const updateTime = () => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
      
      const heroClock = document.getElementById('hero-clock-text');
      if (heroClock) heroClock.innerText = timeStr;
    };

    updateTime();
    this.clockTimer = setInterval(updateTime, 1000);
  }

  // Format Work Start and End Timing
  formatWorkTiming(startTime, endTime) {
    if (!startTime && !endTime) return '09:30 AM → 06:00 PM';
    
    const formatTime = (ts) => {
      if (!ts) return '';
      const d = new Date(ts);
      if (isNaN(d.getTime())) return ts;
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
    };

    const sStr = formatTime(startTime) || '09:30 AM';
    const eStr = formatTime(endTime) || '06:00 PM';
    return `${sStr} → ${eStr}`;
  }

  renderWorkTimingBadge(startTime, endTime) {
    const timingStr = this.formatWorkTiming(startTime, endTime);
    return `
      <div style="display: inline-flex; align-items: center; gap: 5px; background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.2); padding: 2px 8px; border-radius: 4px; font-size: 0.72rem; color: var(--saffron-dark); font-weight: 600;">
        <i class="fa-regular fa-clock" style="font-size: 0.7rem;"></i>
        <span>${timingStr}</span>
      </div>
    `;
  }

  // Real-Time Background Data Synchronization
  startRealtimeSync() {
    if (this.realtimeTimer) clearInterval(this.realtimeTimer);
    
    this.realtimeTimer = setInterval(async () => {
      // Don't interrupt if user is actively writing in the rich text editor
      const isWritingArticle = document.activeElement && (
        document.activeElement.id === 'article-body-editor' || 
        document.activeElement.id === 'article-title' ||
        document.activeElement.id === 'new-comment-text'
      );

      try {
        const notifs = await this.apiGet(`/api/notifications?user_id=${this.currentUser.id}`);
        this.notifications = notifs;
        this.updateNotificationBadge();

        // If on live dashboard or list views and not typing, do a seamless data refresh
        if (!isWritingArticle && ['dashboard', 'tracker', 'reviews', 'final-approvals', 'publishing', 'my-work', 'workload'].includes(this.currentView)) {
          // Check for background data change
          const indicator = document.getElementById('realtime-status-indicator');
          if (indicator) {
            indicator.style.opacity = '1';
          }
        }
      } catch (e) {
        // quiet fail on background sync
      }
    }, 3500);
  }

  // Theme Management (Light / Dark mode)
  applyTheme(theme) {
    this.theme = theme;
    localStorage.setItem('hp_theme', theme);
    const body = document.body;
    const icon = document.getElementById('theme-toggle-icon');

    if (theme === 'light') {
      body.classList.remove('theme-dark');
      body.classList.add('theme-light');
      if (icon) {
        icon.className = 'fa-solid fa-moon';
      }
    } else {
      body.classList.remove('theme-light');
      body.classList.add('theme-dark');
      if (icon) {
        icon.className = 'fa-solid fa-sun';
      }
    }
  }

  toggleTheme() {
    const nextTheme = this.theme === 'dark' ? 'light' : 'dark';
    this.applyTheme(nextTheme);
    this.showToast(`Switched to ${nextTheme.toUpperCase()} mode.`, 'info');
  }

  bindEvents() {
    // Sidebar toggle for mobile & desktop
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebar = document.getElementById('app-sidebar');
    if (sidebarToggle && sidebar) {
      sidebarToggle.addEventListener('click', () => {
        if (window.innerWidth <= 900) {
          sidebar.classList.toggle('mobile-open');
        } else {
          sidebar.classList.toggle('collapsed');
        }
      });
    }

    // Role switcher dropdown
    const rolePill = document.getElementById('role-pill-trigger');
    const roleMenu = document.getElementById('role-menu-dropdown');
    if (rolePill && roleMenu) {
      rolePill.addEventListener('click', (e) => {
        e.stopPropagation();
        roleMenu.classList.toggle('hidden');
      });
    }

    // Notifications toggle
    const notifBtn = document.getElementById('notif-btn');
    const notifDropdown = document.getElementById('notif-dropdown');
    if (notifBtn && notifDropdown) {
      notifBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        notifDropdown.classList.toggle('hidden');
        if (!notifDropdown.classList.contains('hidden')) {
          this.renderNotificationsDropdown();
        }
      });
    }

    // Close dropdowns on outside click
    document.addEventListener('click', (e) => {
      if (roleMenu && !roleMenu.contains(e.target) && e.target !== rolePill) {
        roleMenu.classList.add('hidden');
      }
      if (notifDropdown && !notifDropdown.contains(e.target) && e.target !== notifBtn) {
        notifDropdown.classList.add('hidden');
      }
    });

    // Global Search Input
    const searchInput = document.getElementById('global-search-input');
    const searchDropdown = document.getElementById('search-quick-results');
    if (searchInput && searchDropdown) {
      searchInput.addEventListener('input', async (e) => {
        const q = e.target.value.trim();
        if (q.length < 2) {
          searchDropdown.classList.add('hidden');
          return;
        }

        try {
          const results = await this.apiGet(`/api/content?search=${encodeURIComponent(q)}`);
          if (results.length === 0) {
            searchDropdown.innerHTML = `<div style="padding: 12px; font-size: 0.8rem; color: var(--text-dim); text-align: center;">No matching content found for "${q}"</div>`;
          } else {
            searchDropdown.innerHTML = results.slice(0, 5).map(item => `
              <div class="search-result-item" onclick="app.navigateTo('content-detail', { id: '${item.id}' }); document.getElementById('search-quick-results').classList.add('hidden');">
                <div>
                  <div style="font-weight: 600; font-size: 0.85rem; color: var(--text-primary);">${item.title}</div>
                  <div style="font-size: 0.72rem; color: var(--text-dim);">${item.id} · ${item.category} · ${item.writer ? item.writer.name : 'Unassigned'}</div>
                </div>
                <div>${app.renderStatusPill(item.status, item.is_overdue)}</div>
              </div>
            `).join('');
          }
          searchDropdown.classList.remove('hidden');
        } catch (err) {
          console.error(err);
        }
      });

      document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !searchDropdown.contains(e.target)) {
          searchDropdown.classList.add('hidden');
        }
      });
    }
  }

  handleRoute() {
    const hash = window.location.hash.slice(1) || 'dashboard';
    const [viewName, queryStr] = hash.split('?');
    const params = {};

    if (queryStr) {
      new URLSearchParams(queryStr).forEach((val, key) => {
        params[key] = val;
      });
    }

    this.navigateTo(viewName, params, false);
  }

  navigateTo(view, params = {}, updateHash = true) {
    this.currentView = view;
    this.viewParams = params;

    if (updateHash) {
      const q = new URLSearchParams(params).toString();
      window.location.hash = q ? `${view}?${q}` : view;
    }

    // Update active state in sidebar
    document.querySelectorAll('.sidebar-nav .nav-link').forEach(link => {
      if (link.getAttribute('data-view') === view) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });

    // Close mobile sidebar if open
    const sidebar = document.getElementById('app-sidebar');
    if (sidebar) sidebar.classList.remove('mobile-open');

    this.renderCurrentView();
  }

  async renderCurrentView() {
    const container = document.getElementById('main-content-view');
    if (!container) return;

    window.scrollTo({ top: 0, behavior: 'smooth' });

    switch (this.currentView) {
      case 'dashboard':
        DashboardView.render(container);
        break;
      case 'my-work':
        // Filter tracker by current user
        if (this.currentUser.role === 'Writer') {
          TrackerView.render(container, { writer_id: this.currentUser.id });
        } else if (this.currentUser.role === 'Editor') {
          TrackerView.render(container, { editor_id: this.currentUser.id });
        } else {
          TrackerView.render(container, {});
        }
        break;
      case 'tracker':
        TrackerView.render(container, this.viewParams);
        break;
      case 'all-content':
        TrackerView.render(container, {});
        break;
      case 'kanban':
        KanbanView.render(container);
        break;
      case 'calendar':
        CalendarView.render(container);
        break;
      case 'reviews':
        TrackerView.render(container, { status: 'EDITOR_REVIEW' });
        break;
      case 'final-approvals':
        TrackerView.render(container, { status: 'FINAL_REVIEW' });
        break;
      case 'publishing':
        TrackerView.render(container, { status: 'READY_TO_PUBLISH' });
        break;
      case 'workload':
        WorkloadView.render(container);
        break;
      case 'analytics':
        AnalyticsView.render(container);
        break;
      case 'categories':
        AdminView.render(container, { tab: 'categories' });
        break;
      case 'users':
        AdminView.render(container, { tab: 'users' });
        break;
      case 'content-detail':
        ContentDetailView.render(container, this.viewParams);
        break;
      default:
        DashboardView.render(container);
        break;
    }
  }

  // Switch Active User / Role
  async switchUser(userId) {
    const user = this.users.find(u => u.id === userId);
    if (!user) return;

    this.currentUser = user;
    this.updateHeaderProfile();
    this.showToast(`Switched perspective to: ${user.name} (${user.role})`, "info");
    
    // Close role menu
    const menu = document.getElementById('role-menu-dropdown');
    if (menu) menu.classList.add('hidden');

    this.renderCurrentView();

    // If switched to a Writer (e.g. Pavitra), auto-check for newly assigned or pending kickoff task!
    if (user.role === 'Writer') {
      try {
        const allItems = await this.apiGet('/api/content');
        const pendingKickoffId = sessionStorage.getItem('pending_kickoff_' + user.id);
        
        let targetTask = null;
        if (pendingKickoffId) {
          targetTask = allItems.find(i => i.id === pendingKickoffId);
          sessionStorage.removeItem('pending_kickoff_' + user.id);
        }
        
        if (!targetTask) {
          // Find the most recent active/assigned task for this writer
          targetTask = allItems.find(i => i.writer_id === user.id && ['TOPIC_CREATED', 'ASSIGNED', 'WRITING', 'CHANGES_REQUIRED'].includes(i.status));
        }

        if (targetTask) {
          setTimeout(() => {
            this.showWriterKickoffPopup(targetTask);
          }, 300);
        }
      } catch (e) {
        console.error('Kickoff check failed:', e);
      }
    }
  }

  updateHeaderProfile() {
    const roleBadge = document.getElementById('current-role-badge');
    const userName = document.getElementById('current-user-name');
    const sidebarAvatar = document.getElementById('sidebar-user-avatar');
    const sidebarName = document.getElementById('sidebar-user-name');
    const sidebarRole = document.getElementById('sidebar-user-role');

    if (roleBadge) roleBadge.innerText = this.currentUser.role;
    if (userName) userName.innerText = this.currentUser.name;
    if (sidebarAvatar) sidebarAvatar.innerText = this.currentUser.avatar || 'HP';
    if (sidebarName) sidebarName.innerText = this.currentUser.name;
    if (sidebarRole) sidebarRole.innerText = this.currentUser.title || this.currentUser.role;
  }

  async updateNotificationBadge() {
    try {
      const notifs = await this.apiGet(`/api/notifications?user_id=${this.currentUser.id}`);
      this.notifications = notifs;
      const unread = notifs.filter(n => !n.read).length;
      const badge = document.getElementById('notif-count');
      if (badge) {
        badge.innerText = unread;
        badge.style.display = unread > 0 ? 'flex' : 'none';
      }
    } catch (e) {
      console.error(e);
    }
  }

  renderNotificationsDropdown() {
    const container = document.getElementById('notif-list-container');
    if (!container) return;

    if (this.notifications.length === 0) {
      container.innerHTML = `<div style="padding: 24px; text-align: center; color: var(--text-dim); font-size: 0.8rem;">No notifications at this time.</div>`;
      return;
    }

    container.innerHTML = this.notifications.map(n => `
      <div class="notif-item ${n.read ? '' : 'unread'}" onclick="app.handleNotificationClick('${n.id}', '${n.content_id}')">
        <div style="font-size: 1.1rem; color: var(--saffron-dark);"><i class="fa-solid fa-bell"></i></div>
        <div style="flex: 1;">
          <div class="notif-item-title">${n.title}</div>
          <div class="notif-item-msg">${n.message}</div>
          <div class="notif-item-time">${new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · Aug 24</div>
        </div>
      </div>
    `).join('');
  }

  async handleNotificationClick(notifId, contentId) {
    try {
      await this.apiPost(`/api/notifications/${notifId}/read`);
    } catch (e) {}
    document.getElementById('notif-dropdown').classList.add('hidden');
    this.updateNotificationBadge();
    if (contentId) {
      try {
        const item = await this.apiGet(`/api/content/${contentId}`);
        if (item && this.currentUser.role === 'Writer' && ['TOPIC_CREATED', 'ASSIGNED', 'CHANGES_REQUIRED'].includes(item.status)) {
          this.showWriterKickoffPopup(item);
        } else {
          this.navigateTo('content-detail', { id: contentId });
        }
      } catch (e) {
        this.navigateTo('content-detail', { id: contentId });
      }
    }
  }

  async markAllNotificationsRead() {
    await this.apiPost('/api/notifications/read-all', { user_id: this.currentUser.id });
    this.updateNotificationBadge();
    this.renderNotificationsDropdown();
    this.showToast('All notifications marked as read.', 'info');
  }

  // Create Modal Helpers
  populateCreateModalSelects() {
    const catSelect = document.getElementById('new-category-select');
    const writerSelect = document.getElementById('new-writer-select');
    const editorSelect = document.getElementById('new-editor-select');
    const approverSelect = document.getElementById('new-approver-select');

    if (catSelect) {
      catSelect.innerHTML = this.categories.map(c => `<option value="${c.name}">${c.name}</option>`).join('');
    }
    if (writerSelect) {
      writerSelect.innerHTML = this.users.filter(u => u.role === 'Writer' || u.role === 'Admin').map(u => `
        <option value="${u.id}">${u.name} (${u.role})</option>
      `).join('');
    }
    if (editorSelect) {
      editorSelect.innerHTML = this.users.filter(u => u.role === 'Editor' || u.role === 'Admin').map(u => `
        <option value="${u.id}">${u.name} (${u.role})</option>
      `).join('');
    }
    if (approverSelect) {
      approverSelect.innerHTML = this.users.filter(u => u.role === 'Admin' || u.role === 'Editor' || u.role === 'Publisher').map(u => `
        <option value="${u.id}" ${u.name.includes('Tejaswini') ? 'selected' : ''}>${u.name} (${u.role})</option>
      `).join('');
    }
  }

  escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  openCreateModal() {
    try {
      this.populateCreateModalSelects();
      const modal = document.getElementById('create-modal');
      if (modal) {
        modal.classList.remove('hidden');
        const input = document.getElementById('new-topic-input');
        if (input) input.focus();
      }
    } catch (err) {
      console.error("Error opening create modal:", err);
      this.showToast("Could not open assignment modal: " + err.message, "error");
    }
  }

  closeCreateModal() {
    const modal = document.getElementById('create-modal');
    if (modal) modal.classList.add('hidden');
  }

  openGrammarlyModal(filter = 'all') {
    if (window.ContentDetailView && ContentDetailView.openGrammarlyModal) {
      ContentDetailView.openGrammarlyModal(filter);
    }
  }

  closeGrammarlyModal() {
    const modal = document.getElementById('grammarly-assistant-modal');
    if (modal) modal.classList.add('hidden');
  }

  openAiGrammarModal() {
    this.openGrammarlyModal('all');
  }

  closeAiGrammarModal() {
    this.closeGrammarlyModal();
  }

  openAiAssistantModal(engine = 'gemini') {
    if (window.ContentDetailView && ContentDetailView.openAiAssistantModal) {
      ContentDetailView.openAiAssistantModal(engine);
    }
  }

  closeAiAssistantModal() {
    const modal = document.getElementById('ai-assistant-modal');
    if (modal) modal.classList.add('hidden');
  }

  // APPROVED CONTENT & MEDIA DISTRIBUTION PACKAGE MODAL (BIG POPUP)
  async openApprovedPackageModal(contentId) {
    try {
      let item = this.items ? this.items.find(i => i.id === contentId) : null;
      if (!item) {
        item = await this.apiGet(`/api/content/${contentId}`);
      }
      if (!item) {
        this.showToast('Content not found: ' + contentId, 'error');
        return;
      }
      this.currentPkgItem = item;

      const modal = document.getElementById('approved-package-modal');
      const idSpan = document.getElementById('pkg-modal-id');
      const titleSpan = document.getElementById('pkg-modal-title');
      const contentDiv = document.getElementById('pkg-modal-content');

      if (idSpan) idSpan.innerText = item.id;
      if (titleSpan) titleSpan.innerText = item.title || item.topic;

      // Extract all images
      const images = [];
      if (item.featured_image) {
        images.push({ url: item.featured_image, title: 'Primary Hero Feature Image', tag: 'Hero Banner' });
      }
      if (item.images && Array.isArray(item.images)) {
        item.images.forEach((img, idx) => {
          const url = typeof img === 'string' ? img : (img.url || img.src);
          const caption = typeof img === 'object' ? (img.caption || img.title) : `Story Asset #${idx + 1}`;
          if (url && !images.some(x => x.url === url)) {
            images.push({ url, title: caption, tag: `Asset #${idx + 1}` });
          }
        });
      }
      if (images.length === 0) {
        images.push({ url: '/images/hero-bg.jpg', title: 'Heritage Archival Plate Image', tag: 'Archival Asset' });
      }

      // Writer, Editor, Publisher names
      const writer = this.users.find(u => u.id === item.writer_id) || { name: 'Pavitra', role: 'Writer' };
      const approver = this.users.find(u => u.id === (item.final_approver_id || 'usr-editor-1')) || { name: "Tejaswini Ma'am", role: 'Chief Approver' };
      const publisher = this.users.find(u => u.id === (item.publisher_id || 'usr-publisher-1')) || { name: 'Gowthami', role: 'Publisher' };

      const plainText = `${item.title || item.topic}\n${item.subtitle ? item.subtitle + '\n' : ''}\nBy ${writer.name} | Heritage Pulse Editorial\nCategory: ${item.category} | Shift SLA: ${this.formatWorkTiming(item.work_start_time, item.work_end_time)}\n\n${(item.body || '').replace(/<[^>]*>/g, '')}`;
      const wordCount = (item.body || '').replace(/<[^>]*>/g, ' ').split(/\s+/).filter(Boolean).length;
      const readTime = Math.max(1, Math.ceil(wordCount / 200));
      const publicUrl = item.published_url || `https://heritagepulse.org/stories/${item.id.toLowerCase()}`;
      const shortUrl = `https://hpulse.io/s/${item.id}`;

      contentDiv.innerHTML = `
        <!-- TOP STATS BAR -->
        <div class="pkg-top-stats-bar" style="display: flex; align-items: center; justify-content: space-between; background: var(--bg-card-subtle); padding: 12px 16px; border-radius: var(--radius-md); border: 1px solid var(--border-color); margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
          <div style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap;">
            <div>
              <span style="font-size: 0.7rem; color: var(--text-dim); text-transform: uppercase;">Category</span>
              <div style="font-weight: 700; font-size: 0.85rem; color: ${this.getCategoryColor(item.category)};">${item.category}</div>
            </div>
            <div>
              <span style="font-size: 0.7rem; color: var(--text-dim); text-transform: uppercase;">Word Count</span>
              <div style="font-weight: 700; font-size: 0.85rem; color: var(--text-primary);">${wordCount} words (~${readTime} min read)</div>
            </div>
            <div>
              <span style="font-size: 0.7rem; color: var(--text-dim); text-transform: uppercase;">Final Approver</span>
              <div style="font-weight: 700; font-size: 0.85rem; color: var(--indigo-bright);">✓ ${approver.name}</div>
            </div>
            <div>
              <span style="font-size: 0.7rem; color: var(--text-dim); text-transform: uppercase;">Publisher</span>
              <div style="font-weight: 700; font-size: 0.85rem; color: #10b981;">${publisher.name}</div>
            </div>
          </div>
          <div style="display: flex; gap: 8px;">
            <button class="btn btn-outline-light btn-xs" onclick="app.downloadAllImages()">
              <i class="fa-solid fa-cloud-arrow-down text-saffron"></i> Download All Images (${images.length})
            </button>
            <button class="btn btn-primary btn-xs" onclick="app.copyArticleText('text')" style="background: var(--saffron); color: #000; font-weight: 700;">
              <i class="fa-solid fa-copy"></i> Copy Text
            </button>
          </div>
        </div>

        <!-- 3-SECTION GRID -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 18px;">
          
          <!-- SECTION 1: ARTICLE TEXT EXPORT -->
          <div class="card-panel" style="padding: 16px; display: flex; flex-direction: column;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; flex-wrap: wrap; gap: 6px;">
              <div style="font-size: 0.82rem; font-weight: 800; color: var(--text-primary); text-transform: uppercase; letter-spacing: 0.05em; display: flex; align-items: center; gap: 6px;">
                <i class="fa-solid fa-file-lines text-saffron"></i> 1. Full Article Text
              </div>
              <div style="display: flex; gap: 4px;">
                <button class="btn btn-xs btn-outline-light" onclick="app.copyArticleText('text')" title="Copy Plain Text">
                  <i class="fa-solid fa-copy"></i> Plain Text
                </button>
                <button class="btn btn-xs btn-outline-light" onclick="app.copyArticleText('html')" title="Copy HTML">
                  <i class="fa-solid fa-code"></i> HTML
                </button>
                <button class="btn btn-xs btn-outline-light" onclick="app.copyArticleText('markdown')" title="Copy Markdown">
                  <i class="fa-brands fa-markdown"></i> Markdown
                </button>
              </div>
            </div>
            
            <textarea id="pkg-article-text-area" class="form-control" rows="8" style="font-family: var(--font-mono); font-size: 0.78rem; line-height: 1.5; resize: vertical; flex: 1;" readonly>${plainText}</textarea>
            <div style="font-size: 0.72rem; color: var(--text-dim); margin-top: 6px;">
              💡 Ready to paste directly into CMS (WordPress, Ghost, Webflow, Medium, Social).
            </div>
          </div>

          <!-- SECTION 2: HIGH-RES MEDIA ASSETS & DOWNLOADS -->
          <div class="card-panel" style="padding: 16px; display: flex; flex-direction: column;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; flex-wrap: wrap; gap: 6px;">
              <div style="font-size: 0.82rem; font-weight: 800; color: var(--text-primary); text-transform: uppercase; letter-spacing: 0.05em; display: flex; align-items: center; gap: 6px;">
                <i class="fa-solid fa-images text-saffron"></i> 2. High-Res Media Assets (${images.length})
              </div>
              <button class="btn btn-xs btn-outline-light" onclick="app.downloadAllImages()">
                <i class="fa-solid fa-download text-teal-bright"></i> Download All
              </button>
            </div>

            <div style="display: flex; flex-direction: column; gap: 10px; max-height: 240px; overflow-y: auto; padding-right: 4px;">
              ${images.map((img, idx) => `
                <div style="display: flex; align-items: center; justify-content: space-between; background: var(--bg-card-subtle); border: 1px solid var(--border-color); padding: 8px 10px; border-radius: var(--radius-sm); gap: 10px;">
                  <div style="display: flex; align-items: center; gap: 10px; min-width: 0;">
                    <img src="${img.url}" alt="${this.escapeHtml(img.title)}" style="width: 44px; height: 44px; object-fit: cover; border-radius: 4px; border: 1px solid var(--border-color); flex-shrink: 0;" onerror="this.src='/images/hero-bg.jpg'">
                    <div style="min-width: 0;">
                      <div style="font-size: 0.78rem; font-weight: 700; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        ${this.escapeHtml(img.title)}
                      </div>
                      <span class="badge" style="font-size: 0.65rem; background: rgba(245, 158, 11, 0.15); color: var(--saffron-dark); font-weight: 700;">
                        ${img.tag}
                      </span>
                    </div>
                  </div>
                  <div style="display: flex; gap: 6px; flex-shrink: 0;">
                    <button class="btn btn-xs btn-outline-light" onclick="app.copyToClipboard('${img.url}', 'Image URL')" title="Copy Image Link">
                      <i class="fa-solid fa-link"></i> Link
                    </button>
                    <button class="btn btn-xs btn-primary" onclick="app.downloadImage('${img.url}', '${item.id}-image-${idx + 1}.jpg')" style="background: var(--saffron); color: #000; font-weight: 700;" title="Download High-Res Image">
                      <i class="fa-solid fa-download"></i> Save
                    </button>
                  </div>
                </div>
              `).join('')}
            </div>
            <div style="font-size: 0.72rem; color: var(--text-dim); margin-top: 8px;">
              📷 High-resolution editorial photography cleared for publication.
            </div>
          </div>

        </div>

        <!-- SECTION 3: SHAREABLE PUBLISHING LINKS & EMBEDS -->
        <div class="card-panel" style="padding: 16px; margin-top: 18px;">
          <div style="font-size: 0.82rem; font-weight: 800; color: var(--text-primary); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 12px; display: flex; align-items: center; gap: 6px;">
            <i class="fa-solid fa-share-nodes text-saffron"></i> 3. Shareable Links & Publishing Distribution
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 14px;">
            
            <!-- Live Story URL -->
            <div>
              <label class="form-label" style="font-size: 0.74rem; font-weight: 700; color: var(--text-secondary);">
                🌐 Live Website Story URL
              </label>
              <div style="display: flex; gap: 6px;">
                <input type="text" class="form-control form-control-sm" value="${publicUrl}" id="pkg-live-url" readonly style="font-family: monospace; font-size: 0.78rem;">
                <button class="btn btn-sm btn-outline-light" onclick="app.copyToClipboard(document.getElementById('pkg-live-url').value, 'Story URL')" title="Copy URL">
                  <i class="fa-solid fa-copy"></i>
                </button>
              </div>
            </div>

            <!-- Shortlink -->
            <div>
              <label class="form-label" style="font-size: 0.74rem; font-weight: 700; color: var(--text-secondary);">
                🔗 Shortlink (Social & QR)
              </label>
              <div style="display: flex; gap: 6px;">
                <input type="text" class="form-control form-control-sm" value="${shortUrl}" id="pkg-short-url" readonly style="font-family: monospace; font-size: 0.78rem;">
                <button class="btn btn-sm btn-outline-light" onclick="app.copyToClipboard(document.getElementById('pkg-short-url').value, 'Shortlink')" title="Copy Shortlink">
                  <i class="fa-solid fa-copy"></i>
                </button>
              </div>
            </div>

            <!-- Social Media Tweet Snippet -->
            <div>
              <label class="form-label" style="font-size: 0.74rem; font-weight: 700; color: var(--text-secondary);">
                📱 Social Media Blast Caption
              </label>
              <div style="display: flex; gap: 6px;">
                <input type="text" class="form-control form-control-sm" value="🏛️ Read our latest feature: ${item.title || item.topic} by @${writer.name.toLowerCase()} via @HeritagePulse #Heritage #Culture 👉 ${shortUrl}" id="pkg-social-snippet" readonly style="font-size: 0.78rem;">
                <button class="btn btn-sm btn-outline-light" onclick="app.copyToClipboard(document.getElementById('pkg-social-snippet').value, 'Social Caption')" title="Copy Social Post">
                  <i class="fa-solid fa-copy"></i>
                </button>
              </div>
            </div>

          </div>
        </div>
      `;

      if (modal) modal.classList.remove('hidden');
    } catch (err) {
      console.error("Error opening approval package modal:", err);
      this.showToast("Could not open package: " + err.message, "error");
    }
  }

  closeApprovedPackageModal() {
    const modal = document.getElementById('approved-package-modal');
    if (modal) modal.classList.add('hidden');
  }

  copyArticleText(format = 'text') {
    const item = this.currentPkgItem;
    if (!item) {
      this.showToast('No active story selected', 'error');
      return;
    }
    const writer = this.users.find(u => u.id === item.writer_id) || { name: 'Pavitra' };
    let content = '';

    if (format === 'html') {
      content = `
<article class="heritage-story" data-id="${item.id}" data-category="${item.category}">
  <header>
    <h1>${item.title || item.topic}</h1>
    ${item.subtitle ? `<p class="subtitle">${item.subtitle}</p>` : ''}
    <div class="byline">By <strong>${writer.name}</strong> · Heritage Pulse · ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</div>
  </header>
  ${item.featured_image ? `<figure><img src="${item.featured_image}" alt="${item.title || item.topic}"><figcaption>${item.title || item.topic}</figcaption></figure>` : ''}
  <main>
    ${item.body || '<p>Article content pending.</p>'}
  </main>
</article>
      `.trim();
    } else if (format === 'markdown') {
      content = `# ${item.title || item.topic}\n\n*${item.subtitle || ''}*\n\n**Author:** ${writer.name} | **Category:** ${item.category} | **ID:** ${item.id}\n\n---\n\n${(item.body || '').replace(/<[^>]*>/g, '')}`;
    } else {
      // Plain text
      content = `${item.title || item.topic}\n${item.subtitle ? item.subtitle + '\n' : ''}\nBy ${writer.name} | Heritage Pulse Editorial\nCategory: ${item.category} | ID: ${item.id}\n\n${(item.body || '').replace(/<[^>]*>/g, '')}`;
    }

    this.copyToClipboard(content, `Full Article (${format.toUpperCase()})`);
  }

  downloadImage(url, filename) {
    try {
      const a = document.createElement('a');
      a.href = url;
      a.download = filename || 'heritage-pulse-image.jpg';
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      this.showToast(`Downloading image: ${filename}`, 'info');
    } catch (err) {
      window.open(url, '_blank');
      this.showToast(`Opened image in new tab: ${filename}`, 'info');
    }
  }

  downloadAllImages() {
    const item = this.currentPkgItem;
    if (!item) return;
    const images = [];
    if (item.featured_image) images.push(item.featured_image);
    if (item.images && Array.isArray(item.images)) {
      item.images.forEach(img => {
        const url = typeof img === 'string' ? img : (img.url || img.src);
        if (url && !images.includes(url)) images.push(url);
      });
    }
    if (images.length === 0) images.push('/images/hero-bg.jpg');

    images.forEach((imgUrl, idx) => {
      setTimeout(() => {
        this.downloadImage(imgUrl, `${item.id}-image-${idx + 1}.jpg`);
      }, idx * 300);
    });

    this.showToast(`Initiated download for ${images.length} images!`, 'success');
  }

  copyToClipboard(text, label = 'Content') {
    if (!navigator.clipboard) {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      this.showToast(`Copied ${label} to clipboard!`, 'success');
      return;
    }

    navigator.clipboard.writeText(text).then(() => {
      this.showToast(`Copied ${label} to clipboard!`, 'success');
    }).catch(err => {
      console.error('Clipboard copy error:', err);
      this.showToast('Could not copy to clipboard', 'error');
    });
  }



  selectKickoffRouting(action) {
    document.querySelectorAll('.kickoff-stage-card').forEach(c => c.classList.remove('selected'));
    const target = document.getElementById(`stage-card-${action}`);
    if (target) {
      target.classList.add('selected');
      const radio = target.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;
    }
  }

  async handleCreateContent(e) {
    e.preventDefault();
    const form = e.target;
    const topic = form.topic.value.trim();
    const category = form.category.value;
    const content_type = form.content_type.value;
    const priority = form.priority.value;
    const frequency = form.frequency.value;
    const writer_id = form.writer_id.value;
    const editor_id = form.editor_id.value;
    const final_approver_id = form.final_approver_id.value;
    const deadline = form.deadline.value;
    const work_start_time = form.work_start_time ? form.work_start_time.value : "2026-08-24T09:30";
    const work_end_time = form.work_end_time ? form.work_end_time.value : "2026-08-24T18:00";
    const publishing_date = form.publishing_date.value;
    const short_description = form.short_description.value;
    const tags = form.tags.value.split(',').map(t => t.trim()).filter(Boolean);
    const reference_links = form.reference_links.value;
    const kickoff_action = form.kickoff_action ? form.kickoff_action.value : 'jump';

    try {
      const newItem = await this.apiPost('/api/content', {
        topic,
        title: topic,
        category,
        content_type,
        priority,
        frequency,
        writer_id,
        editor_id,
        final_approver_id,
        publisher_id: 'usr-publisher-1',
        deadline,
        work_start_time,
        work_end_time,
        publishing_date,
        short_description,
        tags: tags.length ? tags : ['HeritagePulse'],
        reference_links,
        sources: reference_links ? [{ id: 'src-1', name: 'Primary Reference Source', url: reference_links }] : []
      });

      this.closeCreateModal();
      form.reset();

      // Set pending kickoff for writer
      sessionStorage.setItem('pending_kickoff_' + writer_id, newItem.id);

      if (kickoff_action === 'jump') {
        this.showToast(`🚀 Instant Kickoff: Opened Workspace for "${topic}"!`, 'success');
        this.navigateTo('content-detail', { id: newItem.id });
      } else {
        this.showToast(`Topic assigned to writer queue: ${newItem.id} - "${topic}"`, 'success');
        this.renderCurrentView();
      }
    } catch (err) {
      this.showToast(`Failed to create topic: ${err.message}`, 'error');
    }
  }

  // WRITER NEW ASSIGNMENT INSTANT KICKOFF POPUP
  showWriterKickoffPopup(task) {
    if (!task) return;
    this.currentKickoffTask = task;

    const modal = document.getElementById('writer-kickoff-modal');
    if (!modal) return;

    const idEl = document.getElementById('writer-kickoff-id');
    const catEl = document.getElementById('writer-kickoff-cat');
    const prioEl = document.getElementById('writer-kickoff-priority');
    const titleEl = document.getElementById('writer-kickoff-title');
    const briefEl = document.getElementById('writer-kickoff-brief');
    const deadlineEl = document.getElementById('writer-kickoff-deadline');
    const editorEl = document.getElementById('writer-kickoff-editor');
    const publisherEl = document.getElementById('writer-kickoff-publisher');
    const statusEl = document.getElementById('writer-kickoff-status');
    const greetingEl = document.getElementById('writer-kickoff-greeting');
    const subEl = document.getElementById('writer-kickoff-sub');

    if (idEl) idEl.innerText = task.id;
    if (catEl) {
      catEl.innerText = task.category;
      catEl.style.borderLeft = `3px solid ${this.getCategoryColor(task.category)}`;
    }
    if (prioEl) prioEl.innerHTML = this.renderPriorityPill(task.priority);
    if (titleEl) titleEl.innerText = task.title;
    if (briefEl) {
      briefEl.innerText = task.short_description || task.notes || 'Comprehensive editorial coverage, background research, and photography documentation required for Heritage Pulse.';
    }
    if (deadlineEl) deadlineEl.innerText = task.deadline;
    if (editorEl) editorEl.innerText = task.editor ? task.editor.name : 'Tejaswini Ma\'am';
    if (publisherEl) publisherEl.innerText = 'Gowthami';
    if (statusEl) statusEl.innerText = `${task.status.replace(/_/g, ' ')} (${task.progress || 10}%)`;
    if (greetingEl) greetingEl.innerText = `New Story Kickoff for ${this.currentUser.name}!`;
    if (subEl) subEl.innerText = `Admin Jitendra has assigned you this heritage story for editorial production.`;

    modal.classList.remove('hidden');
  }

  async acceptWriterKickoff() {
    if (!this.currentKickoffTask) return;
    const task = this.currentKickoffTask;

    try {
      if (task.status === 'TOPIC_CREATED' || task.status === 'ASSIGNED') {
        await this.apiPost(`/api/content/${task.id}/workflow`, {
          status: 'WRITING',
          comment: `Writer ${this.currentUser.name} accepted the task and started writing.`
        });
      }
    } catch (e) {
      console.warn(e);
    }

    this.closeWriterKickoffModal();
    this.navigateTo('content-detail', { id: task.id });
    this.showToast(`🚀 Writing Workspace Opened: "${task.title}"!`, 'success');
  }

  closeWriterKickoffModal() {
    const modal = document.getElementById('writer-kickoff-modal');
    if (modal) modal.classList.add('hidden');
    this.currentKickoffTask = null;
  }

  closeReaderModal() {
    document.getElementById('reader-preview-modal').classList.add('hidden');
  }

  // TODAY MY TASKS POPUP MODAL (Prioritized with Most Urgent on Top)
  async openTodayTasksModal() {
    const modal = document.getElementById('today-tasks-modal');
    const container = document.getElementById('today-tasks-modal-list');
    const titleEl = document.getElementById('today-tasks-modal-title');
    if (!modal || !container) return;

    try {
      container.innerHTML = `
        <div style="padding: 30px; text-align: center; color: var(--text-dim);">
          <div class="spinner" style="margin: 0 auto 12px;"></div>
          <p>Loading your prioritized tasks for today...</p>
        </div>
      `;
      modal.classList.remove('hidden');

      const allItems = await this.apiGet('/api/content');

      // Filter tasks relevant to current perspective
      let userTasks = allItems;
      if (this.currentUser.role === 'Writer') {
        userTasks = allItems.filter(i => i.writer_id === this.currentUser.id);
      } else if (this.currentUser.role === 'Editor') {
        userTasks = allItems.filter(i => i.editor_id === this.currentUser.id || i.final_approver_id === this.currentUser.id || ['WRITER_SUBMITTED', 'EDITOR_REVIEW', 'FINAL_REVIEW'].includes(i.status));
      } else if (this.currentUser.role === 'Publisher') {
        userTasks = allItems.filter(i => ['FINAL_REVIEW', 'READY_TO_PUBLISH', 'PUBLISHED'].includes(i.status));
      }

      // Sort priority score: Overdue (+200), Urgent (+100), High (+50), Medium (+20), Low (+5)
      const getPriorityScore = (item) => {
        let score = 0;
        if (item.is_overdue) score += 200;
        if (item.priority === 'Urgent') score += 100;
        else if (item.priority === 'High') score += 50;
        else if (item.priority === 'Medium') score += 20;
        else score += 5;
        if (item.status === 'CHANGES_REQUIRED') score += 80;
        if (item.status === 'FINAL_REVIEW') score += 70;
        return score;
      };

      userTasks.sort((a, b) => getPriorityScore(b) - getPriorityScore(a));
      this.cachedTodayTasks = userTasks;

      // Update badge counts in modal tabs
      const urgentCount = userTasks.filter(i => i.is_overdue || i.priority === 'Urgent' || i.status === 'CHANGES_REQUIRED').length;
      const writingCount = userTasks.filter(i => ['WRITING', 'IMAGES_UPLOADED', 'ASSIGNED', 'CHANGES_REQUIRED'].includes(i.status)).length;
      const reviewCount = userTasks.filter(i => ['WRITER_SUBMITTED', 'EDITOR_REVIEW', 'FINAL_REVIEW', 'READY_TO_PUBLISH'].includes(i.status)).length;

      document.getElementById('today-modal-count-all').innerText = userTasks.length;
      document.getElementById('today-modal-count-urgent').innerText = urgentCount;
      document.getElementById('today-modal-count-writing').innerText = writingCount;
      document.getElementById('today-modal-count-review').innerText = reviewCount;

      if (titleEl) {
        titleEl.innerText = `Today's Assigned Tasks for ${this.currentUser.name} (${userTasks.length} Active)`;
      }

      this.renderTodayTasksList(userTasks);

    } catch (err) {
      console.error(err);
      container.innerHTML = `<p class="text-crimson-light p-4">Failed to load tasks: ${err.message}</p>`;
    }
  }

  renderTodayTasksList(tasks) {
    const container = document.getElementById('today-tasks-modal-list');
    if (!container) return;

    if (tasks.length === 0) {
      container.innerHTML = `
        <div style="padding: 40px; text-align: center; color: var(--text-dim);">
          <i class="fa-solid fa-circle-check text-teal-bright" style="font-size: 2rem; margin-bottom: 10px; display: block;"></i>
          <strong>All Caught Up!</strong>
          <p style="font-size: 0.8rem; margin-top: 4px;">No active tasks matching this filter.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = tasks.map(item => {
      const isUrgent = item.is_overdue || item.priority === 'Urgent' || item.status === 'CHANGES_REQUIRED';

      return `
        <div class="today-task-card-item ${isUrgent ? 'is-urgent' : ''}" onclick="app.handleTodayTaskClick('${item.id}')">
          <div style="flex: 1;">
            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 6px;">
              <span style="font-family: monospace; font-size: 0.78rem; font-weight: 700; color: var(--saffron-dark);">
                ${item.id}
              </span>
              <span class="cat-badge" style="background: rgba(255,255,255,0.06); border-left: 3px solid ${this.getCategoryColor(item.category)}; font-size: 0.72rem; padding: 2px 8px;">
                ${item.category}
              </span>
              ${this.renderPriorityPill(item.priority)}
              ${this.renderStatusPill(item.status, item.is_overdue)}
              ${isUrgent ? '<span class="status-pill status-overdue" style="font-size: 0.65rem;">🔥 TOP URGENT</span>' : ''}
            </div>

            <div style="font-weight: 600; font-size: 0.95rem; color: var(--text-primary); margin-bottom: 4px;">
              ${item.title}
            </div>

            <div style="display: flex; align-items: center; gap: 14px; font-size: 0.75rem; color: var(--text-dim); flex-wrap: wrap;">
              <span>✍️ Writer: <strong>${item.writer ? item.writer.name : 'Unassigned'}</strong></span>
              <span>🧐 Reviewer: <strong>${item.editor ? item.editor.name : 'Unassigned'}</strong></span>
              <span>🕒 Shift Timing: <strong style="color: var(--saffron-dark);">${this.formatWorkTiming(item.work_start_time, item.work_end_time)}</strong></span>
              <span>📅 Deadline: <strong style="color: ${item.is_overdue ? '#ef4444' : 'var(--text-secondary)'};">${item.deadline}</strong></span>
              <span>📊 Progress: <strong>${item.progress}%</strong></span>
            </div>
          </div>

          <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 6px;">
            <button class="btn btn-secondary btn-sm" style="white-space: nowrap;">
              Open Workspace <i class="fa-solid fa-arrow-right"></i>
            </button>
            <span style="font-size: 0.68rem; color: var(--text-dim);">Click to jump</span>
          </div>
        </div>
      `;
    }).join('');
  }

  filterTodayTasksModal(filterType, tabBtn) {
    document.querySelectorAll('.today-filter-tab').forEach(t => t.classList.remove('active'));
    if (tabBtn) tabBtn.classList.add('active');

    const all = this.cachedTodayTasks || [];
    let filtered = all;

    if (filterType === 'urgent') {
      filtered = all.filter(i => i.is_overdue || i.priority === 'Urgent' || i.status === 'CHANGES_REQUIRED');
    } else if (filterType === 'writing') {
      filtered = all.filter(i => ['WRITING', 'IMAGES_UPLOADED', 'ASSIGNED', 'CHANGES_REQUIRED'].includes(i.status));
    } else if (filterType === 'review') {
      filtered = all.filter(i => ['WRITER_SUBMITTED', 'EDITOR_REVIEW', 'FINAL_REVIEW', 'READY_TO_PUBLISH'].includes(i.status));
    }

    this.renderTodayTasksList(filtered);
  }

  handleTodayTaskClick(contentId) {
    this.closeTodayTasksModal();
    this.navigateTo('content-detail', { id: contentId });
    this.showToast(`Opened workspace for ${contentId}`, 'info');
  }

  closeTodayTasksModal() {
    const modal = document.getElementById('today-tasks-modal');
    if (modal) modal.classList.add('hidden');
  }

  async openDailyReportModal() {
    const modal = document.getElementById('daily-report-modal');
    const container = document.getElementById('daily-report-content');

    try {
      const [analytics, contentList] = await Promise.all([
        this.apiGet('/api/analytics/overview'),
        this.apiGet('/api/content')
      ]);

      const { kpi, categoryStats, teamWorkload } = analytics;

      container.innerHTML = `
        <div style="text-align: center; border-bottom: 2px solid var(--border-color); padding-bottom: 16px; margin-bottom: 20px;">
          <h2 style="font-family: var(--font-display); font-size: 1.6rem; color: var(--text-primary);">HERITAGE PULSE EDITORIAL BOARD</h2>
          <div style="font-size: 0.85rem; color: var(--saffron-dark); font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em;">
            Daily Production Audit & Operations Summary — August 24, 2026
          </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px; text-align: center;">
          <div style="background: var(--bg-card-subtle); padding: 12px; border-radius: 6px; border: 1px solid var(--border-color);">
            <div style="font-size: 1.6rem; font-weight: 800; color: #10b981;">${kpi.publishedToday}</div>
            <div style="font-size: 0.72rem; color: var(--text-dim); text-transform: uppercase;">Articles Published</div>
          </div>
          <div style="background: var(--bg-card-subtle); padding: 12px; border-radius: 6px; border: 1px solid var(--border-color);">
            <div style="font-size: 1.6rem; font-weight: 800; color: var(--indigo-bright);">${kpi.waitingReview}</div>
            <div style="font-size: 0.72rem; color: var(--text-dim); text-transform: uppercase;">In Editor Review</div>
          </div>
          <div style="background: var(--bg-card-subtle); padding: 12px; border-radius: 6px; border: 1px solid var(--border-color);">
            <div style="font-size: 1.6rem; font-weight: 800; color: var(--saffron-dark);">${kpi.inProgress}</div>
            <div style="font-size: 0.72rem; color: var(--text-dim); text-transform: uppercase;">Writing / Images</div>
          </div>
          <div style="background: var(--bg-card-subtle); padding: 12px; border-radius: 6px; border: 1px solid var(--border-color);">
            <div style="font-size: 1.6rem; font-weight: 800; color: ${kpi.overdue > 0 ? '#ef4444' : '#10b981'};">${kpi.overdue}</div>
            <div style="font-size: 0.72rem; color: var(--text-dim); text-transform: uppercase;">Overdue Delayed</div>
          </div>
        </div>

        <h4 style="font-size: 0.95rem; color: var(--text-primary); margin-bottom: 8px;">Editorial Staff Activity Breakdown</h4>
        <div style="margin-bottom: 20px;">
          ${teamWorkload.map(u => `
            <div style="display: flex; justify-content: space-between; font-size: 0.82rem; padding: 6px 0; border-bottom: 1px solid var(--border-color);">
              <div><strong>${u.name}</strong> (${u.role}): ${u.completed} completed, ${u.inReview} in review, ${u.writing} writing</div>
              <div style="color: ${u.overdue > 0 ? '#ef4444' : 'var(--text-dim)'};">${u.overdue > 0 ? `${u.overdue} Overdue` : 'On schedule'}</div>
            </div>
          `).join('')}
        </div>

        <h4 style="font-size: 0.95rem; color: var(--text-primary); margin-bottom: 8px;">Published & In-Flight Stories Today</h4>
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Topic</th>
                <th>Category</th>
                <th>Writer</th>
                <th>Status</th>
                <th>Progress</th>
              </tr>
            </thead>
            <tbody>
              ${contentList.slice(0, 8).map(c => `
                <tr>
                  <td style="font-family: monospace; font-size: 0.78rem; color: var(--saffron-dark);">${c.id}</td>
                  <td style="font-weight: 600; color: var(--text-primary);">${c.title}</td>
                  <td>${c.category}</td>
                  <td>${c.writer ? c.writer.name : 'Staff'}</td>
                  <td>${app.renderStatusPill(c.status, c.is_overdue)}</td>
                  <td><strong>${c.progress}%</strong></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;

      modal.classList.remove('hidden');
    } catch (err) {
      console.error(err);
      this.showToast(`Failed to generate daily report: ${err.message}`, 'error');
    }
  }

  async resetSeedData() {
    if (!confirm('Are you sure you want to reset all content and workflow data to initial demo seed?')) return;
    try {
      await this.apiPost('/api/admin/reset-seed');
      this.showToast('Database reset to initial demo state!', 'success');
      window.location.reload();
    } catch (err) {
      this.showToast(`Reset failed: ${err.message}`, 'error');
    }
  }

  // Toast Notifications
  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    let icon = 'fa-circle-info text-saffron';
    if (type === 'success') icon = 'fa-circle-check text-teal-bright';
    if (type === 'error') icon = 'fa-triangle-exclamation text-crimson-light';

    toast.innerHTML = `
      <i class="fa-solid ${icon}"></i>
      <span>${message}</span>
    `;

    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = '0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  // Utility Badges & Formatters
  renderStatusPill(status, isOverdue = false) {
    if (isOverdue) {
      return `<span class="status-pill status-overdue">OVERDUE</span>`;
    }
    const map = {
      TOPIC_CREATED: { label: "Topic Created", class: "status-topic" },
      ASSIGNED: { label: "Assigned", class: "status-assigned" },
      WRITING: { label: "Writing (25%)", class: "status-writing" },
      CONTENT_COMPLETED: { label: "Content Ready (40%)", class: "status-writing" },
      IMAGES_PENDING: { label: "Images Pending", class: "status-images" },
      IMAGES_UPLOADED: { label: "Images (50%)", class: "status-images" },
      WRITER_SUBMITTED: { label: "Submitted (60%)", class: "status-submitted" },
      EDITOR_REVIEW: { label: "Editor Review (70%)", class: "status-review" },
      CHANGES_REQUIRED: { label: "Changes Req. (35%)", class: "status-changes" },
      EDITOR_APPROVED: { label: "Approved (80%)", class: "status-approved" },
      FINAL_REVIEW: { label: "Final Review (90%)", class: "status-final" },
      READY_TO_PUBLISH: { label: "Ready to Publish (95%)", class: "status-ready" },
      PUBLISHED: { label: "Published (100%)", class: "status-published" }
    };
    const s = map[status] || { label: status, class: "status-topic" };
    return `<span class="status-pill ${s.class}">${s.label}</span>`;
  }

  getStatusClass(status) {
    const map = {
      TOPIC_CREATED: "status-topic",
      ASSIGNED: "status-assigned",
      WRITING: "status-writing",
      IMAGES_UPLOADED: "status-images",
      WRITER_SUBMITTED: "status-submitted",
      EDITOR_REVIEW: "status-review",
      CHANGES_REQUIRED: "status-changes",
      FINAL_REVIEW: "status-final",
      READY_TO_PUBLISH: "status-ready",
      PUBLISHED: "status-published"
    };
    return map[status] || "status-topic";
  }

  renderPriorityPill(priority = 'Medium') {
    const p = priority.toLowerCase();
    return `<span class="priority-pill priority-${p}">${priority}</span>`;
  }

  getCategoryColor(catName) {
    const cat = this.categories.find(c => c.name.toLowerCase() === (catName || '').toLowerCase());
    return cat ? cat.color : '#f59e0b';
  }

  // API HTTP Helpers
  async apiGet(url) {
    const res = await fetch(url, {
      headers: { 'x-user-id': this.currentUser.id }
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
    return res.json();
  }

  async apiPost(url, data = {}) {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': this.currentUser.id
      },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
    return res.json();
  }

  async apiPut(url, data = {}) {
    const res = await fetch(url, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': this.currentUser.id
      },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
    return res.json();
  }

  async apiDelete(url) {
    const res = await fetch(url, {
      method: 'DELETE',
      headers: { 'x-user-id': this.currentUser.id }
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
    return res.json();
  }
}

// Global App Instance
const app = new App();
document.addEventListener('DOMContentLoaded', () => {
  app.init();
});
