// Editorial Content Calendar Controller
const CalendarView = {
  activeView: 'month', // 'month', 'week', 'day'

  async render(container) {
    container.innerHTML = `
      <div class="view-loading">
        <div class="spinner"></div>
        <p>Loading Editorial Calendar...</p>
      </div>
    `;

    try {
      const contentList = await app.apiGet('/api/content');

      container.innerHTML = `
        <div class="view-header">
          <div class="view-title-group">
            <h1>Editorial Content Calendar</h1>
            <p>Publishing schedules, review deadlines, and event coverage milestones for August 2026.</p>
          </div>
          <div class="view-actions">
            <div style="background: var(--bg-card-subtle); border: 1px solid var(--border-color); border-radius: 6px; padding: 2px; display: flex;">
              <button class="btn btn-xs ${this.activeView === 'month' ? 'btn-primary' : 'btn-text'}" onclick="CalendarView.setView('month')">Month</button>
              <button class="btn btn-xs ${this.activeView === 'week' ? 'btn-primary' : 'btn-text'}" onclick="CalendarView.setView('week')">Week</button>
              <button class="btn btn-xs ${this.activeView === 'day' ? 'btn-primary' : 'btn-text'}" onclick="CalendarView.setView('day')">Day (Aug 24)</button>
            </div>
            <button class="btn btn-primary btn-sm" onclick="app.openCreateModal()">
              <i class="fa-solid fa-plus"></i> Schedule Topic
            </button>
          </div>
        </div>

        <!-- CALENDAR CONTAINER -->
        <div class="card-panel" style="padding: 16px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
            <h3 style="font-family: var(--font-display); font-size: 1.25rem; color: var(--text-primary);">
              <i class="fa-regular fa-calendar text-saffron"></i> August 2026
            </h3>
            <div style="display: flex; gap: 12px; font-size: 0.76rem;">
              <span style="display: flex; align-items: center; gap: 6px;"><span style="width: 8px; height: 8px; border-radius: 50%; background: #10b981;"></span> Published Live</span>
              <span style="display: flex; align-items: center; gap: 6px;"><span style="width: 8px; height: 8px; border-radius: 50%; background: #6366f1;"></span> In Review</span>
              <span style="display: flex; align-items: center; gap: 6px;"><span style="width: 8px; height: 8px; border-radius: 50%; background: #f59e0b;"></span> Writing / Media</span>
              <span style="display: flex; align-items: center; gap: 6px;"><span style="width: 8px; height: 8px; border-radius: 50%; background: #ef4444;"></span> Overdue</span>
            </div>
          </div>

          <!-- 7-DAY GRID HEADER -->
          <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 6px; text-align: center; font-weight: 700; font-size: 0.76rem; color: var(--text-dim); padding-bottom: 8px; text-transform: uppercase;">
            <div>Mon</div>
            <div>Tue</div>
            <div>Wed</div>
            <div>Thu</div>
            <div>Fri</div>
            <div>Sat</div>
            <div>Sun</div>
          </div>

          <!-- CALENDAR DAYS GRID (August 2026: Aug 1 is Saturday) -->
          <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 6px; min-height: 480px;">
            ${this.renderCalendarDays(contentList)}
          </div>
        </div>
      `;
    } catch (err) {
      console.error(err);
      container.innerHTML = `<div class="card-panel"><p class="text-crimson-light">Failed to load calendar: ${err.message}</p></div>`;
    }
  },

  renderCalendarDays(contentList) {
    // August 2026 calendar mockup: 31 days. Aug 1 was Saturday (day index 5)
    let cells = '';
    // Empty prefix cells for Mon-Fri before Aug 1
    for (let i = 0; i < 5; i++) {
      cells += `<div style="background: rgba(0,0,0,0.15); border-radius: 6px; opacity: 0.3;"></div>`;
    }

    for (let day = 1; day <= 31; day++) {
      const dateStr = `2026-08-${String(day).padStart(2, '0')}`;
      const isToday = day === 24;
      const dayTasks = contentList.filter(c => c.deadline === dateStr || (c.publishing_date === dateStr && c.status === 'PUBLISHED'));

      cells += `
        <div style="background: ${isToday ? 'rgba(245, 158, 11, 0.08)' : 'var(--bg-card-subtle)'}; border: 1px solid ${isToday ? 'var(--saffron)' : 'var(--border-color)'}; border-radius: 6px; padding: 6px; min-height: 90px; display: flex; flex-direction: column;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
            <span style="font-weight: 700; font-size: 0.8rem; color: ${isToday ? 'var(--saffron)' : 'var(--text-secondary)'};">
              ${day} ${isToday ? '<span class="status-pill status-writing" style="font-size: 0.6rem; padding: 1px 4px;">Today</span>' : ''}
            </span>
            ${dayTasks.length > 0 ? `<span style="font-size: 0.65rem; color: var(--text-dim);">${dayTasks.length} tasks</span>` : ''}
          </div>
          
          <div style="display: flex; flex-direction: column; gap: 3px; overflow-y: auto; flex: 1;">
            ${dayTasks.map(t => {
              let dotColor = '#f59e0b';
              if (t.status === 'PUBLISHED') dotColor = '#10b981';
              else if (t.status === 'EDITOR_REVIEW' || t.status === 'FINAL_REVIEW') dotColor = '#6366f1';
              else if (t.is_overdue) dotColor = '#ef4444';

              return `
                <div style="background: rgba(15, 23, 42, 0.8); border-left: 2px solid ${dotColor}; padding: 2px 4px; border-radius: 2px; font-size: 0.68rem; color: #fff; cursor: pointer; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;" onclick="app.navigateTo('content-detail', { id: '${t.id}' })" title="${t.title} (${t.status})">
                  ${t.title}
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;
    }

    return cells;
  },

  setView(view) {
    this.activeView = view;
    this.render(document.getElementById('main-content-view'));
  }
};
