// Dashboard Home View Controller with Pending Bottleneck Spotlight & Pop Animations
const DashboardView = {
  async render(container) {
    container.innerHTML = `
      <div class="view-loading">
        <div class="spinner"></div>
        <p>Loading Dashboard metrics & workflow bottlenecks...</p>
      </div>
    `;

    try {
      const [analytics, contentList, categories] = await Promise.all([
        app.apiGet('/api/analytics/overview'),
        app.apiGet('/api/content'),
        app.apiGet('/api/categories')
      ]);

      const { kpi, categoryStats } = analytics;
      const todayTasks = contentList.filter(item => item.deadline === '2026-08-24' || (item.updated_at && item.updated_at.startsWith('2026-08-24')));
      const overdueTasks = contentList.filter(item => item.is_overdue);

      // Pending Bottlenecks & Stops
      const waitingFinalApproval = contentList.filter(i => i.status === 'FINAL_REVIEW' || i.status === 'EDITOR_APPROVED');
      const waitingEditorReview = contentList.filter(i => i.status === 'WRITER_SUBMITTED' || i.status === 'EDITOR_REVIEW');
      const changesRequired = contentList.filter(i => i.status === 'CHANGES_REQUIRED');
      const readyToPublish = contentList.filter(i => i.status === 'READY_TO_PUBLISH');

      // Update Urgent Overdue Banner in Header
      const urgentBanner = document.getElementById('urgent-banner');
      const urgentText = document.getElementById('urgent-banner-text');
      if (overdueTasks.length > 0) {
        urgentBanner.classList.remove('hidden');
        urgentText.innerHTML = `<strong>${overdueTasks.length} Overdue Task${overdueTasks.length > 1 ? 's' : ''}</strong> require immediate editorial action: ${overdueTasks.map(t => `"${t.title.slice(0,35)}..."`).join(', ')}`;
      } else {
        urgentBanner.classList.add('hidden');
      }

      const hour = new Date().getHours();
      let greetingTime = "Good morning";
      let greetingIcon = "☀️";
      if (hour >= 12 && hour < 17) {
        greetingTime = "Good afternoon";
        greetingIcon = "🌤️";
      } else if (hour >= 17 && hour < 22) {
        greetingTime = "Good evening";
        greetingIcon = "🌆";
      } else if (hour >= 22 || hour < 5) {
        greetingTime = "Welcome back";
        greetingIcon = "🌙";
      }

      container.innerHTML = `
        <!-- DYNAMIC TIME-BASED HERO GREETING BANNER -->
        <div class="hero-greeting-banner">
          <div class="hero-greeting-left">
            <div class="hero-avatar-pill">${app.currentUser.avatar || 'J'}</div>
            <div>
              <div class="hero-greeting-title">
                ${greetingTime}, ${app.currentUser.name}! <span>${greetingIcon}</span>
              </div>
              <div class="hero-greeting-sub">
                Welcome back to Heritage Pulse Editorial Operations. Here is your live production overview for today.
              </div>
              <div style="display: flex; align-items: center; gap: 10px; margin-top: 12px; flex-wrap: wrap;">
                <button class="btn btn-primary btn-sm hero-tasks-btn" onclick="app.openTodayTasksModal()">
                  <i class="fa-solid fa-list-check"></i>
                  <span>Today My Tasks</span>
                  <span class="badge badge-urgent-count" id="hero-today-badge">${todayTasks.length} Active</span>
                </button>
                <button class="btn btn-outline-light btn-sm" onclick="app.openDailyReportModal()">
                  <i class="fa-solid fa-file-contract text-saffron"></i> Daily Report
                </button>
              </div>
            </div>
          </div>
          <div class="hero-greeting-right">
            <!-- Live Date Badge on Top of Time -->
            <div class="hero-live-date-badge" id="hero-live-date-badge">
              <i class="fa-regular fa-calendar-check text-saffron"></i>
              <span>${new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}</span>
            </div>

            <!-- Live Digital Time -->
            <div class="hero-live-clock" id="hero-live-clock">
              <i class="fa-regular fa-clock text-saffron"></i>
              <span id="hero-clock-text">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })}</span>
            </div>

            <!-- Active Perspective -->
            <div style="font-size: 0.75rem; color: var(--text-dim); margin-top: 2px;">
              Active Perspective: <strong style="color: var(--saffron);">${app.currentUser.name} (${app.currentUser.role})</strong>
            </div>
          </div>
        </div>

        <!-- VIEW HEADER -->
        <div class="view-header">
          <div class="view-title-group">
            <h1>Editorial Operations & Daily Production</h1>
            <p>Real-time workflow monitoring: Topic → Writing → Images → Editor Review → Final Approval → Publishing</p>
          </div>
          <div class="view-actions">
            <button class="btn btn-secondary btn-sm" onclick="app.openDailyReportModal()">
              <i class="fa-solid fa-file-pdf text-saffron"></i> Daily Report (Aug 24)
            </button>
          </div>
        </div>

        <!-- PENDING PROGRESS & WORKFLOW BOTTLENECKS SPOTLIGHT (POP ANIMATION) -->
        <div class="bottlenecks-card">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; flex-wrap: wrap; gap: 10px;">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span class="bottleneck-badge-pulse">
                <i class="fa-solid fa-triangle-exclamation"></i> ACTION REQUIRED
              </span>
              <h3 style="font-family: var(--font-display); font-size: 1.15rem; color: var(--text-primary);">
                Pending Workflow Stops & Approvals Waiting
              </h3>
            </div>
            <span style="font-size: 0.8rem; color: var(--text-dim);">
              Articles currently halted awaiting review or final signoff
            </span>
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 12px;">
            
            <!-- Stop 1: Final Approval Pending -->
            <div class="bottleneck-item-card" onclick="app.navigateTo('tracker', { status: 'FINAL_REVIEW' })" style="border-left: 4px solid var(--purple);">
              <div>
                <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                  <span class="status-pill status-final" style="font-size: 0.68rem;">FINAL APPROVAL PENDING</span>
                  <strong style="color: var(--purple);">${waitingFinalApproval.length}</strong>
                </div>
                <div style="font-size: 0.82rem; font-weight: 600; color: var(--text-primary);">
                  ${waitingFinalApproval.length > 0 ? `"${waitingFinalApproval[0].title.slice(0, 38)}..."` : 'No items waiting'}
                </div>
                <div style="font-size: 0.72rem; color: var(--text-dim); margin-top: 2px;">
                  Awaiting Chief Editor / Admin signoff (90%)
                </div>
              </div>
              <button class="btn btn-xs btn-outline-light">Review & OK</button>
            </div>

            <!-- Stop 2: Editorial Reviewer Pending -->
            <div class="bottleneck-item-card" onclick="app.navigateTo('tracker', { status: 'EDITOR_REVIEW' })" style="border-left: 4px solid var(--indigo);">
              <div>
                <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                  <span class="status-pill status-review" style="font-size: 0.68rem;">EDITOR REVIEW PENDING</span>
                  <strong style="color: var(--indigo-bright);">${waitingEditorReview.length}</strong>
                </div>
                <div style="font-size: 0.82rem; font-weight: 600; color: var(--text-primary);">
                  ${waitingEditorReview.length > 0 ? `"${waitingEditorReview[0].title.slice(0, 38)}..."` : 'No items in review'}
                </div>
                <div style="font-size: 0.72rem; color: var(--text-dim); margin-top: 2px;">
                  Writer submitted; Editor OK required (70%)
                </div>
              </div>
              <button class="btn btn-xs btn-outline-light">Review Copy</button>
            </div>

            <!-- Stop 3: Changes / Revisions Required -->
            <div class="bottleneck-item-card" onclick="app.navigateTo('tracker', { status: 'CHANGES_REQUIRED' })" style="border-left: 4px solid var(--crimson);">
              <div>
                <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                  <span class="status-pill status-changes" style="font-size: 0.68rem;">REVISIONS REQUIRED</span>
                  <strong style="color: #ef4444;">${changesRequired.length}</strong>
                </div>
                <div style="font-size: 0.82rem; font-weight: 600; color: var(--text-primary);">
                  ${changesRequired.length > 0 ? `"${changesRequired[0].title.slice(0, 38)}..."` : 'No active revisions'}
                </div>
                <div style="font-size: 0.72rem; color: var(--text-dim); margin-top: 2px;">
                  Editor sent back to writer with notes (35%)
                </div>
              </div>
              <button class="btn btn-xs btn-outline-light">Fix Issues</button>
            </div>

          </div>
        </div>

        <!-- TOP STATS KPI CARDS -->
        <div class="kpi-grid">
          <div class="kpi-card" style="--accent-color: var(--saffron);" onclick="app.navigateTo('all-content')">
            <div class="kpi-title">
              <span>Total Content</span>
              <i class="fa-solid fa-newspaper text-saffron"></i>
            </div>
            <div class="kpi-value">${kpi.totalContent}</div>
            <div class="kpi-sub">Editorial pipeline across 17 topics</div>
          </div>

          <div class="kpi-card" style="--accent-color: var(--blue);" onclick="app.navigateTo('tracker', { timeframe: 'today' })">
            <div class="kpi-title">
              <span>Today's Tasks</span>
              <i class="fa-solid fa-calendar-day text-blue"></i>
            </div>
            <div class="kpi-value">${kpi.todayTasks}</div>
            <div class="kpi-sub">Active today (Aug 24, 2026)</div>
          </div>

          <div class="kpi-card" style="--accent-color: var(--purple);" onclick="app.navigateTo('tracker', { status: 'WRITING' })">
            <div class="kpi-title">
              <span>In Progress</span>
              <i class="fa-solid fa-pen-nib text-purple"></i>
            </div>
            <div class="kpi-value">${kpi.inProgress}</div>
            <div class="kpi-sub">Writing & photo curation</div>
          </div>

          <div class="kpi-card" style="--accent-color: var(--indigo);" onclick="app.navigateTo('reviews')">
            <div class="kpi-title">
              <span>Waiting Review</span>
              <i class="fa-solid fa-spell-check text-indigo"></i>
            </div>
            <div class="kpi-value">${kpi.waitingReview}</div>
            <div class="kpi-sub">In editor review queue</div>
          </div>

          <div class="kpi-card" style="--accent-color: var(--teal-bright);" onclick="app.navigateTo('publishing')">
            <div class="kpi-title">
              <span>Final Approved</span>
              <i class="fa-solid fa-check-double text-teal-bright"></i>
            </div>
            <div class="kpi-value">${kpi.finalApproved}</div>
            <div class="kpi-sub">Ready for live publishing</div>
          </div>

          <div class="kpi-card" style="--accent-color: #10b981;" onclick="app.navigateTo('tracker', { status: 'PUBLISHED' })">
            <div class="kpi-title">
              <span>Published Today</span>
              <i class="fa-solid fa-globe text-green"></i>
            </div>
            <div class="kpi-value">${kpi.publishedToday}</div>
            <div class="kpi-sub">${kpi.publishedTotal} total published live</div>
          </div>

          <div class="kpi-card" style="--accent-color: var(--crimson-light);" onclick="app.navigateTo('tracker', { filter: 'OVERDUE' })">
            <div class="kpi-title">
              <span>Overdue Tasks</span>
              <i class="fa-solid fa-triangle-exclamation text-crimson-light"></i>
            </div>
            <div class="kpi-value" style="color: ${kpi.overdue > 0 ? '#ef4444' : 'inherit'}">${kpi.overdue}</div>
            <div class="kpi-sub">${kpi.overdue > 0 ? 'Requires immediate action' : 'All on schedule'}</div>
          </div>

          <div class="kpi-card" style="--accent-color: #059669;" onclick="app.navigateTo('analytics')">
            <div class="kpi-title">
              <span>Completion Rate</span>
              <i class="fa-solid fa-percent text-teal-bright"></i>
            </div>
            <div class="kpi-value">${kpi.completedPct}%</div>
            <div class="kpi-progress">
              <div class="kpi-progress-bar" style="width: ${kpi.completedPct}%"></div>
            </div>
          </div>
        </div>

        <!-- 2-COLUMN DASHBOARD BODY -->
        <div style="display: grid; grid-template-columns: 2fr 1.2fr; gap: 24px;">
          
          <!-- LEFT COLUMN: TODAY'S EDITORIAL QUEUE -->
          <div>
            <div class="card-panel">
              <div class="card-panel-header">
                <div class="card-panel-title">
                  <i class="fa-solid fa-list-check text-saffron"></i>
                  <span>Today's Active Editorial Queue</span>
                </div>
                <button class="btn btn-xs btn-outline-light" onclick="app.navigateTo('tracker')">
                  Open Daily Tracker <i class="fa-solid fa-arrow-right"></i>
                </button>
              </div>

              <div class="table-responsive">
                <table class="data-table">
                  <thead>
                    <tr>
                      <th>Topic & Content ID</th>
                      <th>Category</th>
                      <th>Writer & Editor</th>
                      <th>Stage</th>
                      <th>Progress</th>
                      <th>Priority</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${contentList.slice(0, 6).map(item => `
                      <tr onclick="app.navigateTo('content-detail', { id: '${item.id}' })" style="cursor: pointer;">
                        <td>
                          <div style="font-weight: 600; color: var(--text-primary);">${item.title}</div>
                          <div style="font-size: 0.72rem; color: var(--text-dim); margin-top: 2px;">
                            ${item.id} · Due: ${item.deadline}
                            ${item.is_overdue ? '<span class="status-pill status-overdue ml-1">OVERDUE</span>' : ''}
                          </div>
                        </td>
                        <td>
                          <span class="cat-badge" style="background: rgba(255,255,255,0.06); border-left: 3px solid ${app.getCategoryColor(item.category)};">
                            ${item.category}
                          </span>
                        </td>
                        <td>
                          <div style="font-size: 0.78rem;">✍️ ${item.writer ? item.writer.name : 'Unassigned'}</div>
                          <div style="font-size: 0.72rem; color: var(--text-dim);">🧐 ${item.editor ? item.editor.name : 'Unassigned'}</div>
                        </td>
                        <td>
                          ${app.renderStatusPill(item.status, item.is_overdue)}
                        </td>
                        <td>
                          <div class="progress-container" style="min-width: 100px;">
                            <div class="progress-bar-bg">
                              <div class="progress-bar-fill" style="width: ${item.progress}%;"></div>
                            </div>
                            <span class="progress-percent-label">${item.progress}%</span>
                          </div>
                        </td>
                        <td>
                          ${app.renderPriorityPill(item.priority)}
                        </td>
                        <td>
                          <button class="btn btn-xs btn-secondary" onclick="event.stopPropagation(); app.navigateTo('content-detail', { id: '${item.id}' })">
                            Open <i class="fa-solid fa-chevron-right"></i>
                          </button>
                        </td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            </div>

            <!-- FAST TOPIC CREATOR QUICK CARD -->
            <div class="card-panel" style="background: linear-gradient(135deg, rgba(245, 158, 11, 0.06) 0%, var(--bg-card) 100%); border-color: rgba(245, 158, 11, 0.3);">
              <div class="card-panel-header" style="border-bottom-color: rgba(245, 158, 11, 0.2);">
                <div class="card-panel-title">
                  <i class="fa-solid fa-bolt text-saffron"></i>
                  <span>Quick Topic Assignment (Instant Kickoff)</span>
                </div>
              </div>
              <form onsubmit="DashboardView.handleQuickCreate(event)" style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 12px; align-items: end;">
                <div>
                  <label class="form-label" style="font-size: 0.72rem;">Topic / Article Title</label>
                  <input type="text" name="quick_topic" class="form-control" placeholder="e.g. Living Traditions of Warli Folk Paintings" required>
                </div>
                <div>
                  <label class="form-label" style="font-size: 0.72rem;">Category</label>
                  <select name="quick_category" class="form-control" required>
                    ${categories.map(c => `<option value="${c.name}">${c.name}</option>`).join('')}
                  </select>
                </div>
                <div>
                  <label class="form-label" style="font-size: 0.72rem;">Writer</label>
                  <select name="quick_writer" class="form-control">
                    <option value="usr-writer-1">Pavitra</option>
                    <option value="usr-writer-2">Nikitha</option>
                    <option value="usr-writer-3">Sasamka</option>
                  </select>
                </div>
                <div>
                  <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> Assign
                  </button>
                </div>
              </form>
            </div>
          </div>

          <!-- RIGHT COLUMN: WORKFLOW BREAKDOWN & TOP CATEGORIES -->
          <div>
            <!-- WORKFLOW FUNNEL STATUS -->
            <div class="card-panel">
              <div class="card-panel-header">
                <div class="card-panel-title">
                  <i class="fa-solid fa-arrows-split-up-and-left text-indigo"></i>
                  <span>Workflow Journey Breakdown</span>
                </div>
                <button class="btn btn-xs btn-outline-light" onclick="app.navigateTo('kanban')">Kanban</button>
              </div>

              <div style="display: flex; flex-direction: column; gap: 10px;">
                ${[
                  { label: "1. Topic Created", pct: 0, status: "TOPIC_CREATED", color: "var(--stage-topic)" },
                  { label: "2. Writer Assigned", pct: 10, status: "ASSIGNED", color: "var(--stage-assigned)" },
                  { label: "3. Writing Started", pct: 25, status: "WRITING", color: "var(--stage-writing)" },
                  { label: "4. Images Uploaded", pct: 50, status: "IMAGES_UPLOADED", color: "var(--stage-images)" },
                  { label: "5. Writer Submitted", pct: 60, status: "WRITER_SUBMITTED", color: "var(--stage-submitted)" },
                  { label: "6. Editor Review (Tejaswini)", pct: 70, status: "EDITOR_REVIEW", color: "var(--stage-review)" },
                  { label: "7. Revisions Required", pct: 35, status: "CHANGES_REQUIRED", color: "var(--stage-changes)" },
                  { label: "8. Final Approval (Tejaswini)", pct: 90, status: "FINAL_REVIEW", color: "var(--stage-final)" },
                  { label: "9. Ready to Publish", pct: 95, status: "READY_TO_PUBLISH", color: "var(--stage-ready)" },
                  { label: "10. Published Live (Gowthami)", pct: 100, status: "PUBLISHED", color: "var(--stage-published)" }
                ].map(stage => {
                  const count = contentList.filter(i => i.status === stage.status).length;
                  return `
                    <div style="display: flex; align-items: center; justify-content: space-between; font-size: 0.82rem; padding: 6px 10px; background: var(--bg-card-subtle); border-radius: 6px; cursor: pointer;" onclick="app.navigateTo('tracker', { status: '${stage.status}' })">
                      <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="width: 10px; height: 10px; border-radius: 50%; background: ${stage.color};"></span>
                        <span>${stage.label}</span>
                      </div>
                      <div style="display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 0.72rem; color: var(--text-dim);">${stage.pct}%</span>
                        <strong style="color: var(--text-primary); background: rgba(255,255,255,0.08); padding: 1px 8px; border-radius: 10px;">${count}</strong>
                      </div>
                    </div>
                  `;
                }).join('')}
              </div>
            </div>

            <!-- CATEGORY DISTRIBUTION -->
            <div class="card-panel">
              <div class="card-panel-header">
                <div class="card-panel-title">
                  <i class="fa-solid fa-tags text-saffron"></i>
                  <span>Top Editorial Categories</span>
                </div>
                <button class="btn btn-xs btn-outline-light" onclick="app.navigateTo('categories')">All 17</button>
              </div>

              <div style="display: flex; flex-direction: column; gap: 8px;">
                ${categoryStats.slice(0, 5).map(cat => `
                  <div style="display: flex; align-items: center; justify-content: space-between; font-size: 0.82rem;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                      <span style="width: 8px; height: 8px; border-radius: 2px; background: ${cat.color};"></span>
                      <span>${cat.name}</span>
                    </div>
                    <span style="font-weight: 700; color: var(--text-secondary);">${cat.count} articles (${cat.published} live)</span>
                  </div>
                `).join('')}
              </div>
            </div>

          </div>

        </div>
      `;
    } catch (err) {
      console.error(err);
      container.innerHTML = `<div class="card-panel"><p class="text-crimson-light">Failed to load dashboard: ${err.message}</p></div>`;
    }
  },

  async handleQuickCreate(e) {
    e.preventDefault();
    const form = e.target;
    const topic = form.quick_topic.value.trim();
    const category = form.quick_category.value;
    const writer_id = form.quick_writer.value;

    if (!topic) return;

    try {
      const newItem = await app.apiPost('/api/content', {
        topic,
        title: topic,
        category,
        writer_id,
        editor_id: 'usr-editor-1',
        final_approver_id: 'usr-editor-1',
        publisher_id: 'usr-publisher-1',
        priority: 'High',
        deadline: '2026-08-27',
        content_type: 'Featured Article'
      });

      app.showToast(`Topic "${topic}" assigned successfully! (ID: ${newItem.id})`, 'success');
      form.reset();
      app.renderCurrentView();
    } catch (err) {
      app.showToast(`Error creating topic: ${err.message}`, 'error');
    }
  }
};
