// Daily Work Tracker Controller
const TrackerView = {
  activeFilters: {
    timeframe: 'all',
    writer_id: '',
    editor_id: '',
    category: '',
    status: '',
    priority: '',
    search: ''
  },

  async render(container, params = {}) {
    if (params.filter === 'OVERDUE' || params.status === 'OVERDUE') {
      this.activeFilters.status = 'OVERDUE';
    } else if (params.status) {
      this.activeFilters.status = params.status;
    }
    if (params.timeframe) {
      this.activeFilters.timeframe = params.timeframe;
    }

    container.innerHTML = `
      <div class="view-loading">
        <div class="spinner"></div>
        <p>Loading Daily Work Tracker...</p>
      </div>
    `;

    try {
      const queryParams = new URLSearchParams();
      Object.entries(this.activeFilters).forEach(([k, v]) => {
        if (v && v !== 'all') queryParams.append(k, v);
      });

      const [contentList, users, categories] = await Promise.all([
        app.apiGet(`/api/content?${queryParams.toString()}`),
        app.apiGet('/api/users'),
        app.apiGet('/api/categories')
      ]);

      const writers = users.filter(u => u.role === 'Writer');
      const editors = users.filter(u => u.role === 'Editor');

      container.innerHTML = `
        <div class="view-header">
          <div class="view-title-group">
            <h1>Daily Work Tracker & Production Audit</h1>
            <p>Real-time tracking of editorial assignments, writer outputs, editor reviews, and publishing deadlines.</p>
          </div>
          <div class="view-actions">
            <button class="btn btn-secondary btn-sm" onclick="TrackerView.resetFilters()">
              <i class="fa-solid fa-filter-circle-xmark"></i> Clear Filters
            </button>
            <button class="btn btn-primary btn-sm" onclick="app.openCreateModal()" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: #000; font-weight: 800;">
              <i class="fa-solid fa-bolt-lightning"></i> Quick Topic Kickoff
            </button>
          </div>
        </div>

        <!-- FILTER TOOLBAR -->
        <div class="filter-bar">
          <div class="filter-group">
            <!-- Timeframe selector -->
            <select class="filter-select" id="filter-timeframe" onchange="TrackerView.updateFilter('timeframe', this.value)">
              <option value="all" ${this.activeFilters.timeframe === 'all' ? 'selected' : ''}>📅 All Timeframes</option>
              <option value="today" ${this.activeFilters.timeframe === 'today' ? 'selected' : ''}>Today (Aug 24)</option>
              <option value="yesterday" ${this.activeFilters.timeframe === 'yesterday' ? 'selected' : ''}>Yesterday (Aug 23)</option>
              <option value="this_week" ${this.activeFilters.timeframe === 'this_week' ? 'selected' : ''}>This Week (Aug 20-27)</option>
              <option value="this_month" ${this.activeFilters.timeframe === 'this_month' ? 'selected' : ''}>This Month (August 2026)</option>
            </select>

            <!-- Category Filter -->
            <select class="filter-select" id="filter-category" onchange="TrackerView.updateFilter('category', this.value)">
              <option value="">🏷️ All Categories (17)</option>
              ${categories.map(c => `
                <option value="${c.name}" ${this.activeFilters.category === c.name ? 'selected' : ''}>${c.name}</option>
              `).join('')}
            </select>

            <!-- Writer Filter -->
            <select class="filter-select" id="filter-writer" onchange="TrackerView.updateFilter('writer_id', this.value)">
              <option value="">✍️ All Writers</option>
              ${writers.map(w => `
                <option value="${w.id}" ${this.activeFilters.writer_id === w.id ? 'selected' : ''}>${w.name}</option>
              `).join('')}
            </select>

            <!-- Editor Filter -->
            <select class="filter-select" id="filter-editor" onchange="TrackerView.updateFilter('editor_id', this.value)">
              <option value="">🧐 All Editors</option>
              ${editors.map(e => `
                <option value="${e.id}" ${this.activeFilters.editor_id === e.id ? 'selected' : ''}>${e.name}</option>
              `).join('')}
            </select>

            <!-- Status Filter -->
            <select class="filter-select" id="filter-status" onchange="TrackerView.updateFilter('status', this.value)">
              <option value="">⚡ All Stages / Statuses</option>
              <option value="OVERDUE" ${this.activeFilters.status === 'OVERDUE' ? 'selected' : ''}>🚨 Overdue Only</option>
              <option value="TOPIC_CREATED" ${this.activeFilters.status === 'TOPIC_CREATED' ? 'selected' : ''}>Topic Created (0%)</option>
              <option value="ASSIGNED" ${this.activeFilters.status === 'ASSIGNED' ? 'selected' : ''}>Assigned (10%)</option>
              <option value="WRITING" ${this.activeFilters.status === 'WRITING' ? 'selected' : ''}>Writing (25%)</option>
              <option value="IMAGES_UPLOADED" ${this.activeFilters.status === 'IMAGES_UPLOADED' ? 'selected' : ''}>Images Uploaded (50%)</option>
              <option value="WRITER_SUBMITTED" ${this.activeFilters.status === 'WRITER_SUBMITTED' ? 'selected' : ''}>Submitted to Editor (60%)</option>
              <option value="EDITOR_REVIEW" ${this.activeFilters.status === 'EDITOR_REVIEW' ? 'selected' : ''}>Editor Review (70%)</option>
              <option value="CHANGES_REQUIRED" ${this.activeFilters.status === 'CHANGES_REQUIRED' ? 'selected' : ''}>Changes Required (35%)</option>
              <option value="FINAL_REVIEW" ${this.activeFilters.status === 'FINAL_REVIEW' ? 'selected' : ''}>Final Review (90%)</option>
              <option value="READY_TO_PUBLISH" ${this.activeFilters.status === 'READY_TO_PUBLISH' ? 'selected' : ''}>Ready to Publish (95%)</option>
              <option value="PUBLISHED" ${this.activeFilters.status === 'PUBLISHED' ? 'selected' : ''}>Published 100%</option>
            </select>

            <!-- Priority Filter -->
            <select class="filter-select" id="filter-priority" onchange="TrackerView.updateFilter('priority', this.value)">
              <option value="">🔥 All Priorities</option>
              <option value="Urgent" ${this.activeFilters.priority === 'Urgent' ? 'selected' : ''}>Urgent</option>
              <option value="High" ${this.activeFilters.priority === 'High' ? 'selected' : ''}>High</option>
              <option value="Medium" ${this.activeFilters.priority === 'Medium' ? 'selected' : ''}>Medium</option>
              <option value="Low" ${this.activeFilters.priority === 'Low' ? 'selected' : ''}>Low</option>
            </select>
          </div>

          <div style="font-size: 0.8rem; color: var(--text-dim);">
            Showing <strong>${contentList.length}</strong> matching content items
          </div>
        </div>

        <!-- TRACKER DATA TABLE -->
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Content ID</th>
                <th>Topic & Headline</th>
                <th>Category</th>
                <th>Writer</th>
                <th>Editor</th>
                <th>Current Stage</th>
                <th>Progress %</th>
                <th>Priority</th>
                <th>Deadline</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              ${contentList.length === 0 ? `
                <tr>
                  <td colspan="12" style="text-align: center; padding: 40px; color: var(--text-muted);">
                    <i class="fa-solid fa-box-open" style="font-size: 2rem; margin-bottom: 8px; display: block;"></i>
                    No content records match the selected filters.
                  </td>
                </tr>
              ` : contentList.map(item => `
                <tr onclick="app.navigateTo('content-detail', { id: '${item.id}' })" style="cursor: pointer;">
                  <td style="white-space: nowrap; font-size: 0.78rem; color: var(--text-dim);">
                    ${item.start_date ? item.start_date.slice(5) : 'Aug 24'}
                  </td>
                  <td style="font-weight: 700; font-family: monospace; color: var(--saffron);">
                    ${item.id}
                  </td>
                  <td>
                    <div style="font-weight: 600; color: var(--text-primary); max-width: 320px; line-height: 1.35;">${item.title}</div>
                    <div style="display: flex; align-items: center; gap: 8px; font-size: 0.72rem; color: var(--text-dim); margin-top: 3px; flex-wrap: wrap;">
                      <span>${item.content_type}</span>
                      <span>·</span>
                      <span style="color: var(--saffron-dark); font-weight: 600;"><i class="fa-regular fa-clock"></i> ${app.formatWorkTiming(item.work_start_time, item.work_end_time)}</span>
                    </div>
                  </td>
                  <td>
                    <span class="cat-badge" style="background: rgba(255,255,255,0.06); border-left: 3px solid ${app.getCategoryColor(item.category)};">
                      ${item.category}
                    </span>
                  </td>
                  <td>
                    <div style="display: flex; align-items: center; gap: 6px;">
                      <span class="avatar-sm">${item.writer ? item.writer.avatar : '?'}</span>
                      <span style="font-size: 0.8rem;">${item.writer ? item.writer.name : 'Unassigned'}</span>
                    </div>
                  </td>
                  <td>
                    <div style="display: flex; align-items: center; gap: 6px;">
                      <span class="avatar-sm bg-indigo">${item.editor ? item.editor.avatar : '?'}</span>
                      <span style="font-size: 0.8rem;">${item.editor ? item.editor.name : 'Unassigned'}</span>
                    </div>
                  </td>
                  <td>
                    ${app.renderStatusPill(item.status, item.is_overdue)}
                  </td>
                  <td style="min-width: 120px;">
                    <div class="progress-container">
                      <div class="progress-bar-bg">
                        <div class="progress-bar-fill" style="width: ${item.progress}%;"></div>
                      </div>
                      <span class="progress-percent-label">${item.progress}%</span>
                    </div>
                  </td>
                  <td>
                    ${app.renderPriorityPill(item.priority)}
                  </td>
                  <td style="white-space: nowrap; font-size: 0.8rem; color: ${item.is_overdue ? '#ef4444; font-weight: 700;' : 'var(--text-secondary);'}">
                    ${item.deadline}
                    ${item.is_overdue ? '<i class="fa-solid fa-clock text-crimson-light ml-1" title="Overdue"></i>' : ''}
                  </td>
                  <td>
                    <span style="font-size: 0.76rem; font-weight: 600; color: ${item.status === 'PUBLISHED' ? '#4ade80' : 'var(--text-muted)'}">
                      ${item.status === 'PUBLISHED' ? 'Completed' : 'In Progress'}
                    </span>
                  </td>
                  <td>
                    <div style="display: flex; gap: 4px; align-items: center;">
                      <button class="btn btn-xs btn-primary" onclick="event.stopPropagation(); app.navigateTo('content-detail', { id: '${item.id}' })">
                        Workspace
                      </button>
                      <button class="btn btn-xs btn-outline-light" onclick="event.stopPropagation(); app.openApprovedPackageModal('${item.id}')" title="Approved Media Package (Copy Text, Images, Links)" style="border-color: #10b981; color: #10b981; padding: 4px 6px;">
                        <i class="fa-solid fa-box-archive text-teal-bright"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch (err) {
      console.error(err);
      container.innerHTML = `<div class="card-panel"><p class="text-crimson-light">Failed to load tracker: ${err.message}</p></div>`;
    }
  },

  updateFilter(key, value) {
    this.activeFilters[key] = value;
    app.renderCurrentView();
  },

  resetFilters() {
    this.activeFilters = {
      timeframe: 'all',
      writer_id: '',
      editor_id: '',
      category: '',
      status: '',
      priority: '',
      search: ''
    };
    app.renderCurrentView();
  }
};
